# SQLCipher native bridge
-keep class net.zetetic.database.** { *; }
-keep class androidx.room.** { *; }
