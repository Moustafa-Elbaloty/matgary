package com.matgary.app.alerts

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import com.matgary.app.MainActivity
import com.matgary.app.ui.components.AlertKind
import com.matgary.app.ui.components.IslandAlert
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Dynamic Island style pill drawn over every other app (needs the "display over other apps" permission).
 * It pops out of the top of the screen as a tiny black pill, springs open, expands when tapped and shrinks away.
 */
object IslandWindow {
    fun canShow(ctx: Context) = Settings.canDrawOverlays(ctx)

    /** Returns true after the pill was shown and has gone, false if it could not be shown. */
    suspend fun show(ctx: Context, alert: IslandAlert, dest: String): Boolean = withContext(Dispatchers.Main) {
        val gone = CompletableDeferred<Unit>()
        try {
            Pill(ctx.applicationContext, alert, dest) { gone.complete(Unit) }.start()
        } catch (e: Exception) {
            return@withContext false
        }
        gone.await()
        true
    }

    private class Pill(val ctx: Context, val alert: IslandAlert, val dest: String, val onGone: () -> Unit) {
        private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        private val dm = ctx.resources.displayMetrics
        private val handler = Handler(Looper.getMainLooper())
        private fun dp(v: Int) = (v * dm.density).toInt()

        private val tinyW = dp(110)
        private val smallW = minOf((dm.widthPixels * 0.64).toInt(), dp(300))
        private val bigW = (dm.widthPixels * 0.94).toInt()

        private val bg = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = dp(18).toFloat() }
        private val root = LinearLayout(ctx)
        private val header = LinearLayout(ctx)
        private val details = LinearLayout(ctx)
        private val lp = WindowManager.LayoutParams(
            tinyW, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(6) }

        private var expanded = false
        private var finished = false
        private val autoClose = Runnable { dismiss() }

        private fun dotColor() = when (alert.kind) {
            AlertKind.STOCK -> 0xFFF87171.toInt()
            AlertKind.EXPIRY -> 0xFFFBBF24.toInt()
            AlertKind.DEBT -> 0xFF67E8F9.toInt()
        }

        private fun pillButton(label: String, bgColor: Int, fg: Int, onClick: () -> Unit) = TextView(ctx).apply {
            text = label; gravity = Gravity.CENTER; setTextColor(fg); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { setColor(bgColor); cornerRadius = dp(22).toFloat() }
            setOnClickListener { onClick() }
        }

        private fun build() {
            root.apply {
                orientation = LinearLayout.VERTICAL; background = bg; layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(14), dp(9), dp(14), dp(9)); elevation = dp(8).toFloat()
                setOnClickListener { if (!expanded) expand() }
            }
            header.apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; alpha = 0f }
            header.addView(
                View(ctx).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(dotColor()) } },
                LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(10) },
            )
            header.addView(TextView(ctx).apply {
                text = alert.title; setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            })
            root.addView(header)

            details.apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; alpha = 0f }
            alert.lines.forEach { line ->
                details.addView(TextView(ctx).apply { text = line; setTextColor(0xFFD4D4D8.toInt()); textSize = 14f; setPadding(0, dp(4), 0, 0) })
            }
            val buttons = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, 0) }
            buttons.addView(pillButton(alert.actionLabel, Color.WHITE, Color.BLACK) { open() },
                LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
            buttons.addView(pillButton("تجاهل", 0xFF27272A.toInt(), Color.WHITE) { dismiss() }, LinearLayout.LayoutParams(0, dp(44), 1f))
            details.addView(buttons)
            root.addView(details)
        }

        private fun animateTo(width: Int, radiusDp: Int, ms: Long, overshoot: Boolean, end: (() -> Unit)? = null) {
            val fromW = lp.width
            val fromR = bg.cornerRadius
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = ms
                interpolator = if (overshoot) OvershootInterpolator(1.6f) else AccelerateInterpolator()
                addUpdateListener {
                    val t = it.animatedValue as Float
                    lp.width = (fromW + (width - fromW) * t).toInt().coerceAtLeast(dp(40))
                    bg.cornerRadius = fromR + (dp(radiusDp) - fromR) * t.coerceIn(0f, 1f)
                    if (root.isAttachedToWindow) wm.updateViewLayout(root, lp)
                }
                if (end != null) addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) { end() }
                })
                start()
            }
        }

        fun start() {
            build()
            wm.addView(root, lp)
            root.post {
                animateTo(smallW, 22, 480, overshoot = true)
                header.animate().alpha(1f).setStartDelay(160).setDuration(250).start()
                handler.postDelayed(autoClose, 6000)
            }
        }

        private fun expand() {
            expanded = true
            handler.removeCallbacks(autoClose)
            root.setPadding(dp(18), dp(14), dp(18), dp(16))
            details.visibility = View.VISIBLE
            details.animate().alpha(1f).setDuration(280).start()
            animateTo(bigW, 30, 420, overshoot = true)
        }

        private fun open() {
            ctx.startActivity(Intent(ctx, MainActivity::class.java).apply {
                putExtra("dest", dest)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            })
            dismiss()
        }

        private fun dismiss() {
            if (finished) return
            finished = true
            handler.removeCallbacks(autoClose)
            header.animate().alpha(0f).setStartDelay(0).setDuration(150).start()
            details.animate().alpha(0f).setDuration(120).start()
            animateTo(tinyW, 18, 260, overshoot = false) {
                try { wm.removeView(root) } catch (e: IllegalArgumentException) { }
                onGone()
            }
        }
    }
}
