package com.matgary.app.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/** One row of the per-item sales report. */
data class ItemSales(val itemId: Long, val name: String, val qty: Int, val revenue: Double, val profit: Double)

private const val TFIFO = "ORDER BY CASE WHEN expiryDay IS NULL THEN 1 ELSE 0 END, expiryDay, id"
private const val FIFO = "ORDER BY CASE WHEN expiryDay IS NULL THEN 1 ELSE 0 END, expiryDay, receivedDay, id"

@Dao
interface InventoryDao {
    @Insert suspend fun insertItem(item: Item): Long
    @Update suspend fun updateItem(item: Item)
    @Query("DELETE FROM items WHERE id = :id") suspend fun deleteItem(id: Long)
    @Query("SELECT * FROM items ORDER BY name") fun items(): Flow<List<Item>>
    @Query("SELECT * FROM batches WHERE qty > 0") fun liveBatches(): Flow<List<Batch>>
    @Query("SELECT * FROM batches WHERE itemId = :id AND qty > 0 $FIFO") fun batchesOf(id: Long): Flow<List<Batch>>
    @Query("SELECT * FROM batches WHERE itemId = :id AND qty > 0 $FIFO") suspend fun fifoBatches(id: Long): List<Batch>
    @Query("SELECT COALESCE(SUM(qty), 0) FROM batches WHERE itemId = :id") suspend fun stockOf(id: Long): Int
    @Insert suspend fun insertBatch(batch: Batch): Long
    @Query("UPDATE batches SET qty = :qty WHERE id = :id") suspend fun setBatchQty(id: Long, qty: Int)
    @Insert suspend fun insertMovement(m: Movement)
    @Query("SELECT * FROM movements WHERE itemId = :id ORDER BY id DESC LIMIT 30") fun movementsOf(id: Long): Flow<List<Movement>>

    // Truck
    @Insert suspend fun insertLoad(load: Load): Long
    @Insert suspend fun insertLoadLine(line: LoadLine)
    @Insert suspend fun insertTruckBatch(t: TruckBatch)
    @Query("SELECT * FROM truck_batches") fun truckBatches(): Flow<List<TruckBatch>>
    @Query("SELECT * FROM truck_batches") suspend fun allTruckBatches(): List<TruckBatch>
    @Query("DELETE FROM truck_batches") suspend fun clearTruck()
    @Query("SELECT * FROM load_lines WHERE loadId = (SELECT MAX(id) FROM loads)") fun lastLoadLines(): Flow<List<LoadLine>>

    // Sales, returns, waste
    @Insert suspend fun insertCustomer(c: Customer): Long
    @Query("SELECT * FROM customers ORDER BY name") fun customers(): Flow<List<Customer>>
    @Insert suspend fun insertSale(s: Sale): Long
    @Insert suspend fun insertSaleLine(l: SaleLine)
    @Insert suspend fun insertReturn(r: CustomerReturn)
    @Insert suspend fun insertWaste(w: Waste)
    @Query("SELECT * FROM items WHERE id = :id") suspend fun item(id: Long): Item?
    @Query("SELECT COALESCE(SUM(qty), 0) FROM truck_batches WHERE itemId = :id") suspend fun truckStockOf(id: Long): Int
    @Query("SELECT * FROM truck_batches WHERE itemId = :id AND qty > 0 $TFIFO") suspend fun truckFifo(id: Long): List<TruckBatch>
    @Query("UPDATE truck_batches SET qty = :qty WHERE id = :id") suspend fun setTruckQty(id: Long, qty: Int)
    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE day = :day") fun salesTotal(day: Int): Flow<Double>

    // Debts
    @Insert suspend fun insertPayment(p: Payment)
    @Query("SELECT * FROM payments") fun payments(): Flow<List<Payment>>
    @Query("SELECT * FROM sales WHERE customerId IS NOT NULL") fun customerSales(): Flow<List<Sale>>
    @Update suspend fun updateCustomer(c: Customer)

    // Expenses, closing and period totals (from..to are epoch days, inclusive)
    @Insert suspend fun insertExpense(e: Expense)
    @Query("DELETE FROM expenses WHERE id = :id") suspend fun deleteExpense(id: Long)
    @Query("SELECT * FROM expenses ORDER BY time DESC LIMIT 200") fun expenses(): Flow<List<Expense>>
    @Insert suspend fun insertClosing(c: Closing)
    @Query("SELECT * FROM closings WHERE day = :day ORDER BY id DESC LIMIT 1") fun closingFor(day: Int): Flow<Closing?>

    @Query("SELECT COUNT(*) FROM sales WHERE day BETWEEN :a AND :b") suspend fun salesCount(a: Int, b: Int): Int
    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE day BETWEEN :a AND :b") suspend fun salesTotalRange(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE day BETWEEN :a AND :b AND payment = :p") suspend fun salesTotalBy(a: Int, b: Int, p: String): Double
    @Query("SELECT COALESCE(SUM(paid), 0) FROM sales WHERE day BETWEEN :a AND :b AND payment = 'CREDIT'") suspend fun creditPaid(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(cost), 0) FROM sales WHERE day BETWEEN :a AND :b") suspend fun cogs(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(amount), 0) FROM payments WHERE day BETWEEN :a AND :b") suspend fun debtPayments(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(refund), 0) FROM returns WHERE day BETWEEN :a AND :b") suspend fun refunds(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(r.qty * i.buyPrice), 0) FROM returns r JOIN items i ON i.id = r.itemId WHERE r.day BETWEEN :a AND :b AND r.good = 1") suspend fun goodReturnCost(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(qty), 0) FROM returns WHERE day BETWEEN :a AND :b AND good = 1") suspend fun goodReturnQty(a: Int, b: Int): Int
    @Query("SELECT COALESCE(SUM(cost), 0) FROM waste WHERE day BETWEEN :a AND :b") suspend fun wasteCost(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE day BETWEEN :a AND :b") suspend fun expenseTotal(a: Int, b: Int): Double
    @Query("SELECT COALESCE(SUM(ll.qty), 0) FROM load_lines ll JOIN loads l ON l.id = ll.loadId WHERE l.day BETWEEN :a AND :b") suspend fun loadedQty(a: Int, b: Int): Int
    @Query("SELECT COALESCE(SUM(sl.qty), 0) FROM sale_lines sl JOIN sales s ON s.id = sl.saleId WHERE s.day BETWEEN :a AND :b") suspend fun soldQty(a: Int, b: Int): Int
    @Query("SELECT COALESCE(SUM(qty), 0) FROM truck_batches") suspend fun truckQty(): Int

    // Reports
    @Query("SELECT sl.itemId AS itemId, sl.name AS name, SUM(sl.qty) AS qty, SUM(sl.qty * sl.unitPrice) AS revenue, SUM(sl.qty * (sl.unitPrice - sl.unitCost)) AS profit FROM sale_lines sl JOIN sales s ON s.id = sl.saleId WHERE s.day BETWEEN :a AND :b GROUP BY sl.itemId, sl.name")
    suspend fun itemSales(a: Int, b: Int): List<ItemSales>
    @Query("SELECT * FROM items WHERE createdDay <= :cutoff AND id NOT IN (SELECT itemId FROM movements WHERE type = 'OUT' AND day >= :cutoff)")
    suspend fun stagnantCandidates(cutoff: Int): List<Item>
    @Query("SELECT COALESCE(SUM(qty * costPerUnit), 0) FROM batches") suspend fun warehouseCost(): Double
    @Query("SELECT COALESCE(SUM(qty * costPerUnit), 0) FROM truck_batches") suspend fun truckCost(): Double
    @Query("SELECT COALESCE(SUM(b.qty * i.sellPrice), 0) FROM batches b JOIN items i ON i.id = b.itemId") suspend fun warehouseSell(): Double
    @Query("SELECT COALESCE(SUM(t.qty * i.sellPrice), 0) FROM truck_batches t JOIN items i ON i.id = t.itemId") suspend fun truckSell(): Double
}

@Database(
    entities = [
        Item::class, Batch::class, Movement::class, Load::class, LoadLine::class, TruckBatch::class,
        Customer::class, Sale::class, SaleLine::class, CustomerReturn::class, Waste::class, Payment::class,
        Expense::class, Closing::class,
    ],
    version = 5,
    exportSchema = false,
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): InventoryDao
}

/** Adds the truck tables without touching existing data. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `loads` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day` INTEGER NOT NULL, `note` TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `load_lines` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `loadId` INTEGER NOT NULL, `itemId` INTEGER NOT NULL, `qty` INTEGER NOT NULL, " +
                "FOREIGN KEY(`itemId`) REFERENCES `items`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , " +
                "FOREIGN KEY(`loadId`) REFERENCES `loads`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_load_lines_itemId` ON `load_lines` (`itemId`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_load_lines_loadId` ON `load_lines` (`loadId`)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `truck_batches` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `itemId` INTEGER NOT NULL, `qty` INTEGER NOT NULL, `costPerUnit` REAL NOT NULL, `expiryDay` INTEGER, `loadId` INTEGER NOT NULL, " +
                "FOREIGN KEY(`itemId`) REFERENCES `items`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_truck_batches_itemId` ON `truck_batches` (`itemId`)")
    }
}

/** Adds customers, sales, returns and waste. Existing data is kept. */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `customers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `phone` TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `sales` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day` INTEGER NOT NULL, `time` INTEGER NOT NULL, `customerId` INTEGER, `payment` TEXT NOT NULL, `discount` REAL NOT NULL, `total` REAL NOT NULL, `paid` REAL NOT NULL, `cost` REAL NOT NULL)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `sale_lines` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `saleId` INTEGER NOT NULL, `itemId` INTEGER NOT NULL, `name` TEXT NOT NULL, `qty` INTEGER NOT NULL, `unitPrice` REAL NOT NULL, `unitCost` REAL NOT NULL, " +
                "FOREIGN KEY(`saleId`) REFERENCES `sales`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_sale_lines_saleId` ON `sale_lines` (`saleId`)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `returns` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day` INTEGER NOT NULL, `itemId` INTEGER NOT NULL, `name` TEXT NOT NULL, `qty` INTEGER NOT NULL, `refund` REAL NOT NULL, `good` INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `waste` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day` INTEGER NOT NULL, `itemId` INTEGER NOT NULL, `name` TEXT NOT NULL, `qty` INTEGER NOT NULL, `cost` REAL NOT NULL, `reason` TEXT NOT NULL, `source` TEXT NOT NULL)")
    }
}

/** Adds customer payments. Existing data is kept. */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `payments` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `customerId` INTEGER NOT NULL, `day` INTEGER NOT NULL, `time` INTEGER NOT NULL, `amount` REAL NOT NULL, `note` TEXT NOT NULL)")
    }
}

/** Adds expenses and day closings. Existing data is kept. */
val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `expenses` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day` INTEGER NOT NULL, `time` INTEGER NOT NULL, `category` TEXT NOT NULL, `amount` REAL NOT NULL, `note` TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS `closings` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `day` INTEGER NOT NULL, `time` INTEGER NOT NULL, `expectedCash` REAL NOT NULL, `actualCash` REAL NOT NULL, `note` TEXT NOT NULL)")
    }
}
