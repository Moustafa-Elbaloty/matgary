package com.matgary.app.data

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Owner side. The private signing key is created inside the Android Keystore of the owner's phone
 * and can never be exported, so it is not in the APK and customers cannot copy it.
 * Warning: uninstalling the app on the owner's phone deletes this key.
 */
object OwnerKeys {
    private const val ALIAS = "matgary_owner_ec"
    private const val ITERATIONS = 210_000

    private fun keystore() = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    fun hasKey(): Boolean = keystore().containsAlias(ALIAS)

    fun createKey() {
        val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        gen.initialize(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .build()
        )
        gen.generateKeyPair()
    }

    fun publicKeyB64(): String = Crypto.b64(keystore().getCertificate(ALIAS).publicKey.encoded)

    fun sign(data: ByteArray): ByteArray {
        val key = keystore().getKey(ALIAS, null) as PrivateKey
        return Signature.getInstance("SHA256withECDSA").run { initSign(key); update(data); sign() }
    }

    /** True when this phone holds the key that matches the public key built into the app. */
    fun isOwnerDevice(): Boolean =
        hasKey() && (!TrustedKey.isConfigured || publicKeyB64() == TrustedKey.PUBLIC_KEY_B64)

    private fun hash(password: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)).encoded

    fun hasPassword(secure: SecureStore): Boolean = secure.get("owner_hash") != null

    fun setPassword(secure: SecureStore, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        secure.put("owner_salt", Crypto.b64(salt))
        secure.put("owner_hash", Crypto.b64(hash(password, salt)))
    }

    fun checkPassword(secure: SecureStore, password: String): Boolean {
        val salt = secure.get("owner_salt")?.let(Crypto::unb64) ?: return false
        val saved = secure.get("owner_hash")?.let(Crypto::unb64) ?: return false
        return java.security.MessageDigest.isEqual(saved, hash(password, salt))
    }
}
