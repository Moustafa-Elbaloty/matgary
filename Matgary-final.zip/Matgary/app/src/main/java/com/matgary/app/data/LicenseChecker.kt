package com.matgary.app.data

import android.content.Context
import android.provider.Settings
import java.nio.ByteBuffer
import java.security.Signature

sealed interface LicenseResult {
    /** expiryDay = days since 1970-01-01, or 0 for a permanent license. */
    data class Valid(val expiryDay: Int) : LicenseResult
    data class Invalid(val message: String) : LicenseResult
}

/**
 * Activation code = "MTJ1-" + base64(payload + ECDSA signature).
 * payload (14 bytes) = version(1) + device hash(8) + expiry day(4) + reserved(1).
 * The app only holds the public key, so nobody can forge a code from the APK.
 */
object LicenseChecker {
    private const val PREFIX = "MTJ1-"
    private const val VERSION: Byte = 1
    private const val PAYLOAD_LEN = 14
    private const val BAD = "الكود غير صحيح. تأكد منه وجرب تاني."

    fun today(): Int = (System.currentTimeMillis() / 86_400_000L).toInt()

    private fun deviceHash(ctx: Context): ByteArray {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        return Crypto.sha256("$id|${ctx.packageName}".toByteArray()).copyOf(8)
    }

    /** Shown to the customer so the owner can issue a code for exactly this phone. */
    fun deviceCode(ctx: Context): String = Crypto.toHex(deviceHash(ctx)).chunked(4).joinToString("-")

    private fun buildPayload(device: ByteArray, expiryDay: Int): ByteArray =
        ByteBuffer.allocate(PAYLOAD_LEN).put(VERSION).put(device).putInt(expiryDay).put(0).array()

    /** Owner only: needs the private key that exists only in the owner phone's Keystore. */
    fun issue(deviceCodeInput: String, days: Int): String {
        val hex = deviceCodeInput.filter { it.isLetterOrDigit() }.uppercase()
        require(hex.length == 16 && hex.all { it in "0123456789ABCDEF" }) {
            "رقم الجهاز لازم يكون ١٦ حرف من الأرقام و A-F"
        }
        val expiry = if (days == 0) 0 else today() + days
        val payload = buildPayload(Crypto.fromHex(hex), expiry)
        return PREFIX + Crypto.b64(payload + OwnerKeys.sign(payload))
    }

    private fun check(ctx: Context, raw: String): LicenseResult {
        val clean = raw.filter { !it.isWhitespace() }
        if (!clean.startsWith(PREFIX)) return LicenseResult.Invalid(BAD)
        val bytes = try { Crypto.unb64(clean.removePrefix(PREFIX)) } catch (e: IllegalArgumentException) {
            return LicenseResult.Invalid(BAD)
        }
        if (bytes.size < PAYLOAD_LEN + 8) return LicenseResult.Invalid(BAD)
        val payload = bytes.copyOfRange(0, PAYLOAD_LEN)
        val sig = bytes.copyOfRange(PAYLOAD_LEN, bytes.size)
        val key = TrustedKey.publicKey()
            ?: return LicenseResult.Invalid("التطبيق ده مش مجهّز للتفعيل. اتواصل مع صاحب التطبيق.")
        val valid = try {
            Signature.getInstance("SHA256withECDSA").run { initVerify(key); update(payload); verify(sig) }
        } catch (e: Exception) { false }
        if (!valid) return LicenseResult.Invalid(BAD)
        val buf = ByteBuffer.wrap(payload)
        if (buf.get() != VERSION) return LicenseResult.Invalid(BAD)
        val device = ByteArray(8).also { buf.get(it) }
        if (!device.contentEquals(deviceHash(ctx))) return LicenseResult.Invalid("الكود ده متعمل لجهاز تاني.")
        val expiry = buf.int
        if (expiry != 0 && today() > expiry) return LicenseResult.Invalid("الكود انتهت مدته. اطلب كود جديد.")
        return LicenseResult.Valid(expiry)
    }

    /** Called from the activation screen. On success the code is saved encrypted. */
    fun verify(ctx: Context, raw: String): LicenseResult {
        val result = check(ctx, raw)
        if (result is LicenseResult.Valid) {
            val secure = SecureStore(ctx)
            secure.put("license", raw.filter { !it.isWhitespace() })
            secure.put("last_day", today().toString())
        }
        return result
    }

    /** Called on every launch. Also catches the phone clock being moved back to stretch a license. */
    fun status(ctx: Context): LicenseResult {
        val secure = SecureStore(ctx)
        val code = secure.get("license") ?: return LicenseResult.Invalid("")
        val now = today()
        val last = secure.get("last_day")?.toIntOrNull() ?: now
        if (now < last - 1) return LicenseResult.Invalid("تاريخ الموبايل غير صحيح. ظبّط التاريخ والوقت وجرب تاني.")
        secure.put("last_day", maxOf(now, last).toString())
        return check(ctx, code)
    }
}
