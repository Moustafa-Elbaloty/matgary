package com.matgary.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class ThemeMode(val label: String) {
    DAY("نهاري زجاجي"),
    NIGHT("ليلي زجاجي"),
    CLASSIC("كلاسيكي"),
}

data class AppColors(
    val bg: Color,
    val blob: Color,
    val ink: Color,
    val muted: Color,
    val glass: Color,
    val glassBorder: Color,
    val accent: Color,
    val onAccent: Color,
    val good: Color,
    val danger: Color,
    val warn: Color,
    val info: Color,
    val isGlass: Boolean,
    val logoBg: Color,
    val logoBorder: Color,
    val logoStroke: Color,
)

private val DayColors = AppColors(
    bg = Color(0xFFE6EEF5), blob = Color(0xFF93C5FD), ink = Color(0xFF0B2236), muted = Color(0xFF46627A),
    glass = Color(0x99FFFFFF), glassBorder = Color(0xE6FFFFFF),
    accent = Color(0xFF0369A1), onAccent = Color.White,
    good = Color(0xFF15803D), danger = Color(0xFFB91C1C), warn = Color(0xFF92400E), info = Color(0xFF0E5A72),
    isGlass = true,
    logoBg = Color(0x99FFFFFF), logoBorder = Color.White, logoStroke = Color(0xFF0369A1),
)

private val NightColors = AppColors(
    bg = Color(0xFF07161F), blob = Color(0xFF0B6E8A), ink = Color(0xFFEEF4F8), muted = Color(0xFF9DB8C4),
    glass = Color(0x14FFFFFF), glassBorder = Color(0x33FFFFFF),
    accent = Color(0xFF0E7490), onAccent = Color.White,
    good = Color(0xFF86EFAC), danger = Color(0xFFFCA5A5), warn = Color(0xFFFCD34D), info = Color(0xFF67E8F9),
    isGlass = true,
    logoBg = Color(0x12FFFFFF), logoBorder = Color(0x8067E8F9), logoStroke = Color(0xFF67E8F9),
)

private val ClassicColors = AppColors(
    bg = Color(0xFFF3F7FA), blob = Color(0xFFF3F7FA), ink = Color(0xFF0F2A3D), muted = Color(0xFF51697A),
    glass = Color.White, glassBorder = Color(0xFFD5E1E8),
    accent = Color(0xFF0B6E8A), onAccent = Color.White,
    good = Color(0xFF15803D), danger = Color(0xFFB91C1C), warn = Color(0xFF92400E), info = Color(0xFF0E5A72),
    isGlass = false,
    logoBg = Color(0xFF0B6E8A), logoBorder = Color(0xFF0B6E8A), logoStroke = Color.White,
)

private val LocalAppColors = staticCompositionLocalOf { DayColors }

object AppTheme {
    val colors: AppColors
        @Composable get() = LocalAppColors.current
}

@Composable
fun MatgaryTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val colors = when (mode) {
        ThemeMode.DAY -> DayColors
        ThemeMode.NIGHT -> NightColors
        ThemeMode.CLASSIC -> ClassicColors
    }
    val scheme = if (colors.bg.luminance() < 0.5f) darkColorScheme(primary = colors.accent, surface = colors.bg, background = colors.bg)
    else lightColorScheme(primary = colors.accent, surface = colors.bg, background = colors.bg)
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(
            LocalAppColors provides colors,
            LocalLayoutDirection provides LayoutDirection.Rtl,
        ) { content() }
    }
}
