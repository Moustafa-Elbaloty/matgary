package com.matgary.app.data

import java.security.KeyFactory
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec

/**
 * The owner's PUBLIC key. It can only check codes, never create them, so it is safe inside the APK.
 * Leave it empty on the first run, create the owner account (tap the logo 7 times on the activation
 * screen), copy the key it shows, paste it here, then rebuild. Never ship a build with this empty.
 */
object TrustedKey {
    const val PUBLIC_KEY_B64 = ""

    val isConfigured: Boolean get() = PUBLIC_KEY_B64.isNotBlank()

    fun publicKey(): PublicKey? = try {
        if (!isConfigured) null
        else KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Crypto.unb64(PUBLIC_KEY_B64)))
    } catch (e: Exception) { null }
}
