package com.matgary.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** One product. Prices are per single unit (piece). packSize = pieces in one carton. */
@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val barcode: String = "",
    val category: String = "",
    val unit: String = "قطعة",
    val packSize: Int = 1,
    val buyPrice: Double = 0.0,
    val sellPrice: Double = 0.0,
    val minQty: Int = 0,
    val createdDay: Int = 0,
)

/** One received lot of an item. qty is what is still left. Selling takes from the earliest expiry first. */
@Entity(
    tableName = "batches",
    foreignKeys = [ForeignKey(Item::class, ["id"], ["itemId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("itemId")],
)
data class Batch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val qty: Int,
    val initialQty: Int,
    val costPerUnit: Double,
    val expiryDay: Int?,
    val receivedDay: Int,
)

/** History line. type: IN, OUT, WASTE, ADJUST. */
@Entity(tableName = "movements", indices = [Index("itemId")])
data class Movement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val type: String,
    val qty: Int,
    val day: Int,
    val note: String = "",
)

/** One loading of the truck (usually one per morning). */
@Entity(tableName = "loads")
data class Load(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val note: String = "",
)

@Entity(
    tableName = "load_lines",
    foreignKeys = [
        ForeignKey(Item::class, ["id"], ["itemId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(Load::class, ["id"], ["loadId"], onDelete = ForeignKey.CASCADE),
    ],
    indices = [Index("itemId"), Index("loadId")],
)
data class LoadLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loadId: Long,
    val itemId: Long,
    val qty: Int,
)

/** Stock that is on the truck right now. It keeps the expiry and cost of the warehouse batch it came from. */
@Entity(
    tableName = "truck_batches",
    foreignKeys = [ForeignKey(Item::class, ["id"], ["itemId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("itemId")],
)
data class TruckBatch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val qty: Int,
    val costPerUnit: Double,
    val expiryDay: Int?,
    val loadId: Long,
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
)

/** One sale from the truck. payment: CASH, WALLET or CREDIT. paid < total means the customer owes the rest (step 6). */
@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val time: Long,
    val customerId: Long?,
    val payment: String,
    val discount: Double,
    val total: Double,
    val paid: Double,
    val cost: Double,
)

/** name is copied so old sales stay readable even if the item is deleted later. */
@Entity(
    tableName = "sale_lines",
    foreignKeys = [ForeignKey(Sale::class, ["id"], ["saleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("saleId")],
)
data class SaleLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val itemId: Long,
    val name: String,
    val qty: Int,
    val unitPrice: Double,
    val unitCost: Double,
)

@Entity(tableName = "returns")
data class CustomerReturn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val itemId: Long,
    val name: String,
    val qty: Int,
    val refund: Double,
    val good: Boolean,
)

/** Loss record. source: WAREHOUSE, TRUCK or RETURN. cost = what the goods cost us. */
@Entity(tableName = "waste")
data class Waste(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val itemId: Long,
    val name: String,
    val qty: Int,
    val cost: Double,
    val reason: String,
    val source: String,
)

/** Money a customer paid back against what they owe. */
@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val day: Int,
    val time: Long,
    val amount: Double,
    val note: String = "",
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val time: Long,
    val category: String,
    val amount: Double,
    val note: String = "",
)

/** End-of-day cash check: what the app expected vs what the trader counted. */
@Entity(tableName = "closings")
data class Closing(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val day: Int,
    val time: Long,
    val expectedCash: Double,
    val actualCash: Double,
    val note: String = "",
)
