package com.matgary.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Small key-value store encrypted with AES-GCM. The key lives in the Android Keystore and cannot be exported. */
class SecureStore(context: Context) {
    private val sp = context.getSharedPreferences("matgary_secure", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun put(name: String, value: String) {
        val cipher = Cipher.getInstance(TRANSFORM).apply { init(Cipher.ENCRYPT_MODE, key()) }
        val sealed = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        sp.edit().putString(name, Crypto.b64(sealed)).apply()
    }

    fun get(name: String): String? {
        val raw = sp.getString(name, null) ?: return null
        return try {
            val all = Crypto.unb64(raw)
            val cipher = Cipher.getInstance(TRANSFORM).apply {
                init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all, 0, 12))
            }
            String(cipher.doFinal(all, 12, all.size - 12), Charsets.UTF_8)
        } catch (e: Exception) { null }
    }

    fun remove(name: String) { sp.edit().remove(name).apply() }

    private companion object {
        const val ALIAS = "matgary_store_key"
        const val TRANSFORM = "AES/GCM/NoPadding"
    }
}
