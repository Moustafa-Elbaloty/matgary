package com.matgary.app.data

import java.time.LocalDate

object Dates {
    const val WARN_DAYS = 7
    const val OVERDUE_DAYS = 15
    fun today(): Int = LocalDate.now().toEpochDay().toInt()
    fun fmt(day: Int): String = LocalDate.ofEpochDay(day.toLong()).toString()
}

object Fmt {
    /** Accepts Arabic-Indic digits and the Arabic decimal separator. */
    fun num(s: String): Double? = s.trim().map {
        when (it) {
            in '٠'..'٩' -> '0' + (it - '٠')
            '٫', '،', ',' -> '.'
            else -> it
        }
    }.joinToString("").toDoubleOrNull()

    fun money(d: Double): String = if (d % 1.0 == 0.0) d.toLong().toString() else "%.2f".format(d)
}
