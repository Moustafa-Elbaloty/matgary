package com.matgary.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.ui.components.AppLogo
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

@Composable
internal fun fieldColors() = AppTheme.colors.let {
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = it.ink, unfocusedTextColor = it.ink,
        focusedBorderColor = it.accent, unfocusedBorderColor = it.glassBorder,
        focusedLabelColor = it.accent, unfocusedLabelColor = it.muted, cursorColor = it.accent,
    )
}

@Composable
internal fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    val c = AppTheme.colors
    Button(
        onClick = onClick, enabled = enabled,
        modifier = modifier.fillMaxWidth().heightIn(min = 52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
    ) { Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}

/** verify returns null on success, or the error message to show. */
@Composable
fun ActivationScreen(
    deviceCode: String,
    notice: String?,
    verify: (String) -> String?,
    onActivated: () -> Unit,
    onOwnerEntry: () -> Unit,
) {
    val c = AppTheme.colors
    val clipboard = LocalClipboardManager.current
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(notice) }
    var taps by remember { mutableIntStateOf(0) }
    ScreenBackground {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Hidden entry to the owner account: tap the logo 7 times.
            AppLogo(
                96.dp,
                Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    taps++
                    if (taps >= 7) { taps = 0; onOwnerEntry() }
                },
            )
            Spacer(Modifier.height(16.dp))
            Text("تفعيل متجري", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("الصق كود التفعيل اللي وصلك", color = c.muted, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = code, onValueChange = { code = it; error = null },
                        label = { Text("كود التفعيل") }, minLines = 2, maxLines = 4, isError = error != null,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                    )
                    TextButton(onClick = { clipboard.getText()?.text?.let { code = it; error = null } }) {
                        Text("لصق من الحافظة", color = c.accent)
                    }
                    error?.let { Text(it, color = c.danger, fontSize = 13.sp) }
                    Spacer(Modifier.height(8.dp))
                    PrimaryButton("تفعيل", enabled = code.isNotBlank()) {
                        error = verify(code)
                        if (error == null) onActivated()
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("رقم جهازك (ابعته لصاحب التطبيق عشان يعملك الكود):", color = c.muted, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(deviceCode, color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { clipboard.setText(AnnotatedString(deviceCode)) }) { Text("نسخ", color = c.accent) }
            }
        }
    }
}

@Composable
fun StoreSetupScreen(onSave: (String) -> Unit) {
    val c = AppTheme.colors
    var name by remember { mutableStateOf("") }
    ScreenBackground {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AppLogo(96.dp)
            Spacer(Modifier.height(16.dp))
            Text("اسم متجرك", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("هيظهر في الإيصالات والتقارير، وتقدر تغيّره بعدين", color = c.muted, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("اسم المتجر أو المخزن") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                    )
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton("ابدأ", enabled = name.isNotBlank()) { onSave(name) }
                }
            }
        }
    }
}
