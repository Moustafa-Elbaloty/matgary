package com.matgary.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.DebtRow
import com.matgary.app.data.Dates
import com.matgary.app.data.Fmt
import com.matgary.app.data.LedgerEntry
import com.matgary.app.data.db.Customer
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

/** Egyptian mobile numbers (01xxxxxxxxx) become 201xxxxxxxxx for WhatsApp. Other formats are used as typed. */
private fun waNumber(phone: String): String {
    val d = phone.filter { it.isDigit() }
    return when {
        d.startsWith("00") -> d.drop(2)
        d.startsWith("0") -> "20" + d.drop(1)
        else -> d
    }
}

@Composable
fun DebtsScreen(rows: List<DebtRow>, onOpen: (Long) -> Unit, onAddCustomer: (String, String) -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    var adding by remember { mutableStateOf(false) }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("المديونيات", onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("إجمالي المستحق لك", color = c.muted, fontSize = 13.sp)
                    Text(Fmt.money(rows.sumOf { it.balance }), color = c.warn, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("${rows.size} عميل عليهم فلوس", color = c.muted, fontSize = 13.sp)
                }
            }
            if (rows.isEmpty()) {
                Text("مفيش مديونيات. أي بيع بالأجل هيظهر هنا.", color = c.muted, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows, key = { it.customer.id }) { r ->
                        GlassCard(Modifier.fillMaxWidth().clickable { onOpen(r.customer.id) }) {
                            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(r.customer.name, color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                    r.oldestOpenDay?.let {
                                        val age = today - it
                                        if (age > Dates.OVERDUE_DAYS) Tag("متأخر $age يوم", c.danger) else Tag("من $age يوم", c.muted)
                                    }
                                }
                                Text(Fmt.money(r.balance), color = c.ink, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
            TextButton(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة عميل", color = c.accent) }
        }
    }
    if (adding) CustomerFormDialog("عميل جديد", "", "", { adding = false }) { n, p -> onAddCustomer(n, p); adding = false }
}

@Composable
fun CustomerDebtScreen(
    customer: Customer, balance: Double, ledger: List<LedgerEntry>, storeName: String,
    onPay: (Double) -> Unit, onSaveCustomer: (String, String) -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    val ctx = LocalContext.current
    var dialog by remember { mutableIntStateOf(0) } // 1 pay, 2 edit

    fun open(intent: Intent) { try { ctx.startActivity(intent) } catch (e: ActivityNotFoundException) { } }

    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar(customer.name, onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("المتبقي عليه", color = c.muted, fontSize = 13.sp)
                    Text(
                        if (balance > 0.005) Fmt.money(balance) else "مفيش مديونية",
                        color = if (balance > 0.005) c.warn else c.good, fontSize = 28.sp, fontWeight = FontWeight.Black,
                    )
                    if (customer.phone.isNotBlank()) Text(customer.phone, color = c.muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            PrimaryButton("تسجيل دفعة", enabled = balance > 0.005) { dialog = 1 }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val msg = "أهلاً ${customer.name}، تذكير بسيط من $storeName: المتبقي عليك ${Fmt.money(balance)}. شكراً ليك."
                        open(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${waNumber(customer.phone)}?text=${Uri.encode(msg)}")))
                    },
                    enabled = balance > 0.005 && customer.phone.isNotBlank(),
                    modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp),
                ) { Text("تذكير واتساب", color = c.accent, fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = { open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}"))) },
                    enabled = customer.phone.isNotBlank(),
                    modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp),
                ) { Text("اتصال", color = c.accent, fontWeight = FontWeight.Bold) }
            }
            Text("كشف الحساب", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
            if (ledger.isEmpty()) Text("لسه مفيش حركات.", color = c.muted, fontSize = 13.sp)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ledger, key = { "${it.time}-${it.amount}" }) { e ->
                    GlassCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(e.title, color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(Dates.fmt(e.day), color = c.muted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text((if (e.amount > 0) "+" else "") + Fmt.money(e.amount), color = if (e.amount > 0) c.warn else c.good, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text("الرصيد ${Fmt.money(e.balanceAfter)}", color = c.muted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            TextButton(onClick = { dialog = 2 }, modifier = Modifier.fillMaxWidth()) { Text("تعديل بيانات العميل", color = c.accent) }
        }
    }
    when (dialog) {
        1 -> PayDialog(balance, { dialog = 0 }) { onPay(it); dialog = 0 }
        2 -> CustomerFormDialog("بيانات العميل", customer.name, customer.phone, { dialog = 0 }) { n, p -> onSaveCustomer(n, p); dialog = 0 }
    }
}

@Composable
private fun PayDialog(balance: Double, onDismiss: () -> Unit, onConfirm: (Double) -> Unit) {
    var amount by remember { mutableStateOf("") }
    val v = Fmt.num(amount) ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("تسجيل دفعة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المتبقي ${Fmt.money(balance)}", fontSize = 13.sp)
                NumField("المبلغ المدفوع", amount) { amount = it }
                TextButton(onClick = { amount = Fmt.money(balance) }) { Text("المبلغ كله") }
                if (v > balance + 0.005) Text("المبلغ أكبر من المتبقي.", fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(enabled = v > 0 && v <= balance + 0.005, onClick = { onConfirm(v.coerceAtMost(balance)) }) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}

@Composable
private fun CustomerFormDialog(title: String, name0: String, phone0: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf(name0) }
    var phone by remember { mutableStateOf(phone0) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("الموبايل (للتذكير على واتساب)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(name.trim(), phone.trim()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}
