package com.matgary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Dates
import com.matgary.app.ui.components.AppLogo
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** onSubmit checks the PIN and reports back through the callback. */
@Composable
fun LockScreen(pinLength: Int, bioEnabled: Boolean, onSubmit: (String, (Boolean) -> Unit) -> Unit, onBio: () -> Unit) {
    val c = AppTheme.colors
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var fails by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { if (bioEnabled) onBio() }

    fun press(d: String) {
        if (busy || pin.length >= pinLength) return
        pin += d
        error = false
        if (pin.length == pinLength) {
            busy = true
            onSubmit(pin) { ok ->
                if (!ok) scope.launch {
                    fails++
                    error = true
                    delay(500L * fails.coerceAtMost(8))
                    pin = ""
                    busy = false
                }
            }
        }
    }

    @Composable
    fun Key(label: String, onClick: () -> Unit) {
        OutlinedButton(onClick = onClick, modifier = Modifier.size(72.dp), shape = CircleShape, contentPadding = PaddingValues(0.dp)) {
            Text(label, color = c.ink, fontSize = if (label.length > 1) 13.sp else 24.sp, fontWeight = FontWeight.Bold)
        }
    }

    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            AppLogo(72.dp)
            Spacer(Modifier.height(16.dp))
            Text("اكتب الـ PIN", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Row(Modifier.padding(vertical = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(pinLength) { i ->
                    Box(Modifier.size(16.dp).clip(CircleShape).background(if (i < pin.length) c.accent else c.glassBorder))
                }
            }
            Text(if (error) "الـ PIN غلط" else " ", color = c.danger, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9").chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { row.forEach { d -> Key(d) { press(d) } } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (bioEnabled) Key("بصمة") { onBio() } else Spacer(Modifier.size(72.dp))
                    Key("0") { press("0") }
                    Key("مسح") { if (!busy) { pin = pin.dropLast(1); error = false } }
                }
            }
        }
    }
}

@Composable
fun BackupScreen(
    lastBackupDay: Int, pickedName: String?,
    onCreate: (password: String) -> Unit, onPick: () -> Unit,
    onRestore: (password: String, done: (String?) -> Unit) -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var rpw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("النسخ الاحتياطي", onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إنشاء نسخة", color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (lastBackupDay > 0) "آخر نسخة: ${Dates.fmt(lastBackupDay)}" else "لسه ماعملتش نسخة احتياطية.", color = c.muted, fontSize = 13.sp)
                    Text("النسخة بتتشفّر بكلمة سر من اختيارك. من قائمة المشاركة اختار جوجل درايف أو واتساب أو أي مكان. لو نسيت كلمة السر مفيش أي طريقة نرجّع بيها النسخة.", color = c.muted, fontSize = 12.sp)
                    OutlinedTextField(pw, { pw = it }, label = { Text("كلمة سر النسخة (٦ أحرف على الأقل)") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                    OutlinedTextField(pw2, { pw2 = it }, label = { Text("أعد كتابة كلمة السر") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                    PrimaryButton("إنشاء ومشاركة النسخة", enabled = pw.length >= 6 && pw == pw2) { onCreate(pw) }
                }
            }
            GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("استرجاع نسخة", color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("الاسترجاع بيمسح البيانات اللي على الموبايل ده ويحط بيانات النسخة مكانها.", color = c.warn, fontSize = 12.sp)
                    OutlinedButton(onClick = onPick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text(pickedName ?: "اختار ملف النسخة", color = c.accent, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(rpw, { rpw = it; error = null }, label = { Text("كلمة سر النسخة") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                    error?.let { Text(it, color = c.danger, fontSize = 13.sp) }
                    PrimaryButton("استرجاع", enabled = pickedName != null && rpw.isNotEmpty() && !busy) { confirm = true }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("استرجاع النسخة؟") },
        text = { Text("كل البيانات الحالية هتتمسح ويتحط مكانها بيانات النسخة، والتطبيق هيتقفل ويفتح تاني.") },
        confirmButton = {
            TextButton(onClick = { confirm = false; busy = true; onRestore(rpw) { e -> error = e; busy = false } }) { Text("استرجاع") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } },
    )
}
