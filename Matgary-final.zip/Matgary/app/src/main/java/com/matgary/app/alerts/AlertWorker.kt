package com.matgary.app.alerts

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.matgary.app.data.AppState
import com.matgary.app.data.Config
import com.matgary.app.data.Dates
import com.matgary.app.data.Flag
import com.matgary.app.data.Fmt
import com.matgary.app.data.InventoryRepo
import com.matgary.app.data.LicenseChecker
import com.matgary.app.data.LicenseResult
import com.matgary.app.data.SecureStore
import com.matgary.app.data.flags
import com.matgary.app.ui.components.AlertKind
import com.matgary.app.ui.components.IslandAlert
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

/** Looks at stock, expiry dates and debts, then shows the island pill and a notification even when the app is closed. */
class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    private suspend fun buildAlerts(repo: InventoryRepo): List<IslandAlert> {
        val rows = repo.rows().first()
        val debts = repo.debts().first()
        val d = Dates.today()
        return buildList<IslandAlert> {
            val low = rows.filter { r -> r.flags(Dates.WARN_DAYS, d).any { it == Flag.OUT || it == Flag.LOW } }
            if (low.isNotEmpty()) add(IslandAlert(AlertKind.STOCK, "${low.size} أصناف خلصت أو ناقصة", low.take(3).map { "${it.item.name} · الرصيد ${it.stock}" }, "عرض المخزن"))
            val exp = rows.filter { r -> r.flags(Dates.WARN_DAYS, d).any { it == Flag.EXPIRED || it == Flag.EXPIRING } }
            if (exp.isNotEmpty()) add(IslandAlert(AlertKind.EXPIRY, "${exp.size} أصناف قربت صلاحيتها", exp.take(3).map { r ->
                val e = r.nearestExpiry ?: d
                "${r.item.name} · " + if (e < d) "منتهي" else "باقي ${e - d} يوم"
            }, "عرض المخزن"))
            val late = debts.filter { r -> r.oldestOpenDay?.let { d - it > Dates.OVERDUE_DAYS } == true }
            if (late.isNotEmpty()) add(IslandAlert(AlertKind.DEBT, "${late.size} عملاء متأخرين في الدفع", late.take(3).map { "${it.customer.name} · ${Fmt.money(it.balance)}" }, "المديونيات"))
        }
    }

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val test = inputData.getBoolean("test", false)
        if (AppState.foreground && !test) return Result.success()
        if (Config.REQUIRE_ACTIVATION && !test && LicenseChecker.status(ctx) !is LicenseResult.Valid) return Result.success()

        val secure = SecureStore(ctx)
        var alerts: List<IslandAlert> = emptyList()
        if (secure.get("db_pass") != null) {
            val repo = InventoryRepo(ctx, secure)
            try { alerts = buildAlerts(repo) } finally { repo.close() }
        }
        if (test && alerts.isEmpty()) {
            alerts = listOf(IslandAlert(AlertKind.STOCK, "تجربة: ٣ أصناف خلصت", listOf("كنافة بالقشطة · الرصيد 0", "بسبوسة · الرصيد 0", "جيلاتي شوكولاتة · الرصيد 0"), "عرض المخزن"))
        }
        if (alerts.isEmpty()) return Result.success()

        // The same alerts are not repeated more than once every 12 hours.
        val sig = alerts.joinToString("|") { it.title }
        val now = System.currentTimeMillis()
        if (!test && secure.get("alert_sig") == sig && now - (secure.get("alert_time")?.toLongOrNull() ?: 0L) < 12 * 3_600_000L) {
            return Result.success()
        }
        secure.put("alert_sig", sig)
        secure.put("alert_time", now.toString())

        val overlay = IslandWindow.canShow(ctx)
        if (Notifier.canNotify(ctx)) alerts.forEachIndexed { i, a -> Notifier.post(ctx, 100 + i, a, quiet = overlay) }
        if (overlay) IslandWindow.show(ctx, alerts.first(), destOf(alerts.first()))
        return Result.success()
    }
}

object AlertScheduler {
    private const val NAME = "matgary_alerts"

    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<AlertWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun cancel(ctx: Context) { WorkManager.getInstance(ctx).cancelUniqueWork(NAME) }

    /** One alert after 6 seconds, so you can leave the app and watch it appear over the home screen. */
    fun testNow(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<AlertWorker>().setInitialDelay(6, TimeUnit.SECONDS).setInputData(workDataOf("test" to true)).build()
        WorkManager.getInstance(ctx).enqueue(req)
    }
}
