package com.matgary.app.alerts

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.matgary.app.MainActivity
import com.matgary.app.R
import com.matgary.app.ui.components.AlertKind
import com.matgary.app.ui.components.IslandAlert

/** Where tapping an alert should take the trader. */
fun destOf(a: IslandAlert) = if (a.kind == AlertKind.DEBT) "DEBTS" else "INVENTORY"

/** Normal Android notifications (status bar and notification shade). */
object Notifier {
    private const val HIGH = "alerts_high"
    private const val QUIET = "alerts_quiet"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(HIGH, "تنبيهات المتجر", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(QUIET, "تنبيهات المتجر (هادية)", NotificationManager.IMPORTANCE_LOW))
    }

    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    /** quiet = the island pill is already on screen, so skip the heads-up banner and only keep a line in the shade. */
    fun post(ctx: Context, id: Int, alert: IslandAlert, quiet: Boolean) {
        ensureChannels(ctx)
        val open = Intent(ctx, MainActivity::class.java).apply {
            putExtra("dest", destOf(alert))
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, if (quiet) QUIET else HIGH)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(alert.title)
            .setContentText(alert.lines.firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(alert.lines.joinToString("\n")))
            .setContentIntent(pi).setAutoCancel(true)
            .setPriority(if (quiet) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }
}
