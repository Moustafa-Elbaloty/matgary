package com.matgary.app.data

object Config {
    /**
     * TEMPORARY test switch. false = the app opens without an activation code (testing).
     * Set it to true before selling the app, then build again.
     */
    const val REQUIRE_ACTIVATION = false

    /** Direct link to the newest APK built by GitHub. Change the user and repository name if they differ. */
    const val UPDATE_URL = "https://github.com/Moustafa-Elbaloty/matgary/releases/latest/download/matgary.apk"
}
