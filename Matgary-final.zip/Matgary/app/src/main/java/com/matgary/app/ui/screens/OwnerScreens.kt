package com.matgary.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.LicenseChecker
import com.matgary.app.data.OwnerKeys
import com.matgary.app.data.SecureStore
import com.matgary.app.data.TrustedKey
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Gate { WRONG_DEVICE, SETUP, SHOW_KEY, LOGIN }

/** Hidden owner entry: first-time setup on the owner's phone, then password login. */
@Composable
fun OwnerGateScreen(secure: SecureStore, onUnlocked: () -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var gate by remember {
        mutableStateOf(
            when {
                !OwnerKeys.hasKey() && TrustedKey.isConfigured -> Gate.WRONG_DEVICE
                !OwnerKeys.hasKey() || !OwnerKeys.hasPassword(secure) -> Gate.SETUP
                !OwnerKeys.isOwnerDevice() -> Gate.WRONG_DEVICE
                else -> Gate.LOGIN
            }
        )
    }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var fails by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }

    ScreenBackground {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            when (gate) {
                Gate.WRONG_DEVICE -> {
                    Text("غير متاح", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("حساب المالك مش متاح على الجهاز ده.", color = c.muted, fontSize = 14.sp)
                    Spacer(Modifier.height(20.dp))
                    PrimaryButton("رجوع", onClick = onBack)
                }

                Gate.SETUP -> {
                    Text("إنشاء حساب المالك", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("هيتعمل مفتاح التوقيع داخل موبايلك ومش هيخرج منه.", color = c.muted, fontSize = 14.sp)
                    Spacer(Modifier.height(16.dp))
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                pw, { pw = it; error = null }, label = { Text("كلمة سر المالك (٨ أحرف على الأقل)") },
                                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                pw2, { pw2 = it; error = null }, label = { Text("أعد كتابة كلمة السر") },
                                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                            )
                            error?.let { Text(it, color = c.danger, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                            Spacer(Modifier.height(12.dp))
                            PrimaryButton("إنشاء الحساب", enabled = !busy) {
                                when {
                                    pw.length < 8 -> error = "كلمة السر لازم تكون ٨ أحرف على الأقل."
                                    pw != pw2 -> error = "كلمتا السر مش متطابقتين."
                                    else -> {
                                        busy = true
                                        scope.launch {
                                            withContext(Dispatchers.Default) {
                                                if (!OwnerKeys.hasKey()) OwnerKeys.createKey()
                                                OwnerKeys.setPassword(secure, pw)
                                            }
                                            busy = false
                                            if (TrustedKey.isConfigured) onUnlocked() else gate = Gate.SHOW_KEY
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Gate.SHOW_KEY -> {
                    val pub = OwnerKeys.publicKeyB64()
                    Text("المفتاح العام", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text(
                        "انسخه والصقه في ملف TrustedKey.kt مكان PUBLIC_KEY_B64، وابنِ التطبيق تاني قبل ما تبيعه. " +
                            "ما تمسحش التطبيق من موبايلك، لأن ده بيمسح مفتاح التوقيع.",
                        color = c.muted, fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(16.dp))
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            SelectionContainer { Text(pub, color = c.ink, fontSize = 12.sp) }
                            TextButton(onClick = { clipboard.setText(AnnotatedString(pub)) }) { Text("نسخ المفتاح", color = c.accent) }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("متابعة", onClick = onUnlocked)
                }

                Gate.LOGIN -> {
                    Text("دخول المالك", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(16.dp))
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                pw, { pw = it; error = null }, label = { Text("كلمة السر") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                            )
                            error?.let { Text(it, color = c.danger, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                            Spacer(Modifier.height(12.dp))
                            PrimaryButton("دخول", enabled = !busy && pw.isNotEmpty()) {
                                busy = true
                                scope.launch {
                                    val ok = withContext(Dispatchers.Default) { OwnerKeys.checkPassword(secure, pw) }
                                    if (ok) onUnlocked() else {
                                        fails++
                                        error = "كلمة السر غلط."
                                        delay(1000L * fails.coerceAtMost(10))
                                    }
                                    busy = false
                                }
                            }
                        }
                    }
                    TextButton(onClick = onBack) { Text("رجوع", color = c.muted) }
                }
            }
        }
    }
}

/** Owner panel: create a code for one customer phone. Customers never see this screen. */
@Composable
fun OwnerPanelScreen(onOpenApp: () -> Unit, onExit: () -> Unit) {
    val c = AppTheme.colors
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var device by remember { mutableStateOf("") }
    var days by remember { mutableIntStateOf(30) }
    var code by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val plans = listOf("شهر" to 30, "٣ شهور" to 90, "سنة" to 365, "دائم" to 0)

    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
            Text("لوحة المالك", color = c.ink, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("اعمل كود تفعيل لموبايل عميل", color = c.muted, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        device, { device = it; error = null; code = null },
                        label = { Text("رقم جهاز العميل (١٦ حرف)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("مدة الترخيص", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        plans.forEach { (label, d) ->
                            val on = d == days
                            Button(
                                onClick = { days = d; code = null },
                                modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (on) c.accent else c.glass,
                                    contentColor = if (on) c.onAccent else c.ink,
                                ),
                            ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                    error?.let { Text(it, color = c.danger, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton("إنشاء الكود", enabled = device.isNotBlank()) {
                        try { code = LicenseChecker.issue(device, days); error = null }
                        catch (e: IllegalArgumentException) { error = e.message; code = null }
                    }
                }
            }
            code?.let { value ->
                Spacer(Modifier.height(16.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("الكود جاهز", color = c.good, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        SelectionContainer { Text(value, color = c.ink, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)) }
                        Row {
                            TextButton(onClick = { clipboard.setText(AnnotatedString(value)) }) { Text("نسخ", color = c.accent) }
                            TextButton(onClick = {
                                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, value) }
                                ctx.startActivity(Intent.createChooser(send, "مشاركة الكود"))
                            }) { Text("مشاركة", color = c.accent) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("إعدادات مخفية", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("الربط بالسيرفر وسجل الأكواد الصادرة هيتضافوا هنا في الخطوات الجاية. الشاشة دي بتظهر لحسابك بس.", color = c.muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            PrimaryButton("فتح التطبيق", onClick = onOpenApp)
            TextButton(onClick = onExit) { Text("خروج من حساب المالك", color = c.muted) }
        }
    }
}
