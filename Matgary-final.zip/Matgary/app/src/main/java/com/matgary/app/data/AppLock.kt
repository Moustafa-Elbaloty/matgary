package com.matgary.app.data

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** App PIN. Only a salted hash is stored (encrypted by the Keystore), never the PIN itself. */
object AppLock {
    private const val ITERATIONS = 100_000

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, 256)).encoded

    fun isEnabled(s: SecureStore) = s.get("pin_hash") != null
    fun pinLength(s: SecureStore) = s.get("pin_len")?.toIntOrNull() ?: 4
    fun bioEnabled(s: SecureStore) = s.get("pin_bio") == "1"
    fun setBio(s: SecureStore, on: Boolean) = s.put("pin_bio", if (on) "1" else "0")

    fun set(s: SecureStore, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        s.put("pin_salt", Crypto.b64(salt))
        s.put("pin_hash", Crypto.b64(hash(pin, salt)))
        s.put("pin_len", pin.length.toString())
    }

    fun check(s: SecureStore, pin: String): Boolean {
        val salt = s.get("pin_salt")?.let(Crypto::unb64) ?: return false
        val saved = s.get("pin_hash")?.let(Crypto::unb64) ?: return false
        return MessageDigest.isEqual(saved, hash(pin, salt))
    }

    fun clear(s: SecureStore) {
        listOf("pin_salt", "pin_hash", "pin_len", "pin_bio").forEach { s.remove(it) }
    }
}
