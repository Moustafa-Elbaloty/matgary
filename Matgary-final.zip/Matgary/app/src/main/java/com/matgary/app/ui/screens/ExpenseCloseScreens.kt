package com.matgary.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.DaySummary
import com.matgary.app.data.Dates
import com.matgary.app.data.Fmt
import com.matgary.app.data.TruckRow
import com.matgary.app.data.db.Closing
import com.matgary.app.data.db.Expense
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

private val CATEGORIES = listOf("بنزين", "صيانة", "أكل وشرب", "رواتب", "إيجار", "متفرقات")

@Composable
fun ExpensesScreen(
    expenses: List<Expense>, monthTotal: Double,
    onAdd: (category: String, amount: Double, note: String) -> Unit, onDelete: (Long) -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Expense?>(null) }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("المصاريف", onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("النهاردة", color = c.muted, fontSize = 13.sp)
                        Text(Fmt.money(expenses.filter { it.day == today }.sumOf { it.amount }), color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("الشهر ده", color = c.muted, fontSize = 13.sp)
                        Text(Fmt.money(monthTotal), color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            if (expenses.isEmpty()) {
                Text("لسه مفيش مصاريف.", color = c.muted, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(expenses, key = { it.id }) { e ->
                        GlassCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(e.category, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(Dates.fmt(e.day) + if (e.note.isNotBlank()) " · ${e.note}" else "", color = c.muted, fontSize = 12.sp)
                                }
                                Text(Fmt.money(e.amount), color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                TextButton(onClick = { deleting = e }) { Text("حذف", color = c.danger, fontSize = 12.sp) }
                            }
                        }
                    }
                }
            }
            PrimaryButton("إضافة مصروف", Modifier.padding(vertical = 12.dp)) { adding = true }
        }
    }
    if (adding) {
        var cat by remember { mutableStateOf(CATEGORIES[0]) }
        var amount by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false }, title = { Text("مصروف جديد") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CATEGORIES.chunked(3).forEach { rowCats ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            rowCats.forEach { k -> FilterChip(selected = cat == k, onClick = { cat = k }, label = { Text(k, fontSize = 12.sp) }) }
                        }
                    }
                    NumField("المبلغ", amount) { amount = it }
                    OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = { TextButton(enabled = (Fmt.num(amount) ?: 0.0) > 0, onClick = { onAdd(cat, Fmt.num(amount) ?: 0.0, note); adding = false }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("إلغاء") } },
        )
    }
    deleting?.let { e ->
        AlertDialog(
            onDismissRequest = { deleting = null }, title = { Text("حذف المصروف؟") },
            text = { Text("${e.category} · ${Fmt.money(e.amount)}") },
            confirmButton = { TextButton(onClick = { onDelete(e.id); deleting = null }) { Text("حذف", color = c.danger) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun Line(label: String, value: String, color: Color? = null, bold: Boolean = false) {
    val c = AppTheme.colors
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = c.muted, fontSize = 14.sp)
        Text(value, color = color ?: c.ink, fontSize = if (bold) 17.sp else 14.sp, fontWeight = if (bold) FontWeight.Black else FontWeight.SemiBold)
    }
}

@Composable
fun CloseDayScreen(
    day: Int, summary: DaySummary?, closing: Closing?,
    onDay: (Int) -> Unit, onSave: (actualCash: Double, note: String) -> Unit, onCount: () -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    var actual by remember(day, closing) { mutableStateOf(closing?.let { Fmt.money(it.actualCash) } ?: "") }
    var note by remember(day, closing) { mutableStateOf(closing?.note ?: "") }
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("تقفيل اليوم", onBack)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onDay(day - 1) }) { Text("اليوم السابق", color = c.accent) }
                Text(if (day == today) "النهاردة · ${Dates.fmt(day)}" else Dates.fmt(day), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { onDay(day + 1) }, enabled = day < today) { Text("اليوم التالي", color = if (day < today) c.accent else c.muted) }
            }
            if (summary == null) {
                Text("جاري الحساب...", color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
            } else {
                val s = summary
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("الأرباح", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Line("عدد الفواتير", "${s.salesCount}")
                        Line("المبيعات", Fmt.money(s.salesTotal))
                        if (s.refunds > 0) Line("مرتجعات", "- ${Fmt.money(s.refunds)}", c.warn)
                        Line("إجمالي الربح", Fmt.money(s.grossProfit))
                        if (s.wasteCost > 0) Line("هالك وعجز", "- ${Fmt.money(s.wasteCost)}", c.danger)
                        Line("مصاريف", "- ${Fmt.money(s.expenses)}", c.warn)
                        Line("صافي الربح", Fmt.money(s.netProfit), if (s.netProfit >= 0) c.good else c.danger, bold = true)
                    }
                }
                GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("الكاش", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Line("مبيعات كاش", Fmt.money(s.cashSales))
                        if (s.creditPaid > 0) Line("مدفوع من فواتير الأجل", Fmt.money(s.creditPaid))
                        if (s.debtPayments > 0) Line("دفعات مديونيات", Fmt.money(s.debtPayments))
                        if (s.refunds > 0) Line("مرتجعات", "- ${Fmt.money(s.refunds)}", c.warn)
                        Line("مصاريف", "- ${Fmt.money(s.expenses)}", c.warn)
                        Line("الكاش المتوقع معاك", Fmt.money(s.expectedCash), bold = true)
                        if (s.walletSales > 0) Line("على المحفظة (مش كاش)", Fmt.money(s.walletSales))
                        if (s.creditTotal - s.creditPaid > 0.005) Line("أجل لسه متحصّلش", Fmt.money(s.creditTotal - s.creditPaid), c.warn)
                        NumField("الكاش اللي معاك فعلًا", actual, Modifier.padding(top = 8.dp)) { actual = it }
                        if (actual.isNotBlank()) {
                            val diff = (Fmt.num(actual) ?: 0.0) - s.expectedCash
                            when {
                                diff > 0.005 -> Line("زيادة", Fmt.money(diff), c.good, bold = true)
                                diff < -0.005 -> Line("عجز", Fmt.money(-diff), c.danger, bold = true)
                                else -> Line("الحساب", "مظبوط", c.good, bold = true)
                            }
                        }
                        OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                        PrimaryButton(if (closing == null) "حفظ التقفيل" else "تحديث التقفيل", Modifier.padding(top = 12.dp), enabled = actual.isNotBlank()) {
                            onSave(Fmt.num(actual) ?: 0.0, note)
                        }
                        if (closing != null) Text("اتقفل بكاش ${Fmt.money(closing.actualCash)}", color = c.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("البضاعة", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Line("خرج للعربية", "${s.loadedQty} قطعة")
                        Line("اتباع", "${s.soldQty} قطعة")
                        if (s.goodReturnQty > 0) Line("مرتجع سليم", "${s.goodReturnQty} قطعة")
                        Line("المفروض يفضل على العربية", "${s.truckQty} قطعة", bold = true)
                        PrimaryButton("جرد العربية", Modifier.padding(top = 12.dp), enabled = day == today, onClick = onCount)
                    }
                }
            }
            androidx.compose.foundation.layout.Spacer(Modifier.padding(bottom = 24.dp))
        }
    }
}

@Composable
fun TruckCountScreen(rows: List<TruckRow>, onApply: (Map<Long, Int>) -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val typed = remember { mutableStateMapOf<Long, String>() }
    var confirm by remember { mutableStateOf(false) }
    fun actualOf(r: TruckRow) = typed[r.item.id]?.let { Fmt.num(it)?.toInt() } ?: r.qty
    val shortage = rows.sumOf { (it.qty - actualOf(it)).coerceAtLeast(0) }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("جرد العربية", onBack)
            Text("اكتب العدد اللي عدّيته فعلًا. الفرق هيتسجل عجز أو زيادة.", color = c.muted, fontSize = 13.sp)
            if (rows.isEmpty()) {
                Text("العربية فاضية.", color = c.muted, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows, key = { it.item.id }) { r ->
                        val a = actualOf(r)
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(r.item.name, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("المفروض ${r.qty}", color = c.muted, fontSize = 13.sp)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    NumField("العدد الفعلي", typed[r.item.id] ?: r.qty.toString(), Modifier.weight(1f)) { typed[r.item.id] = it }
                                    when {
                                        a < r.qty -> Tag("عجز ${r.qty - a}", c.danger)
                                        a > r.qty -> Tag("زيادة ${a - r.qty}", c.good)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            PrimaryButton("تطبيق الجرد", Modifier.padding(vertical = 12.dp), enabled = rows.isNotEmpty()) { confirm = true }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("تطبيق الجرد؟") },
        text = { Text(if (shortage > 0) "العجز ($shortage قطعة) هيتسجل خسارة بتكلفته، والزيادة هتتضاف للعربية." else "الأرصدة هتتعدّل حسب العدد اللي كتبته.") },
        confirmButton = { TextButton(onClick = { confirm = false; onApply(rows.associate { it.item.id to actualOf(it) }) }) { Text("تطبيق") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } },
    )
}
