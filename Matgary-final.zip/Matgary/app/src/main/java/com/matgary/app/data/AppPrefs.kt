package com.matgary.app.data

import android.content.Context
import com.matgary.app.ui.theme.ThemeMode

/** Local storage for simple settings. Step 3 moves the real data to an encrypted Room database. */
class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("matgary_prefs", Context.MODE_PRIVATE)

    var themeMode: ThemeMode
        get() = ThemeMode.entries.firstOrNull { it.name == sp.getString("theme", null) } ?: ThemeMode.DAY
        set(value) = sp.edit().putString("theme", value.name).apply()

    var activated: Boolean
        get() = sp.getBoolean("activated", false)
        set(value) = sp.edit().putBoolean("activated", value).apply()

    var lastBackupDay: Int
        get() = sp.getInt("last_backup", 0)
        set(value) = sp.edit().putInt("last_backup", value).apply()

    var storeName: String
        get() = sp.getString("store_name", "") ?: ""
        set(value) = sp.edit().putString("store_name", value.trim()).apply()
}
