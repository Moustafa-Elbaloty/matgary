package com.matgary.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import android.widget.Toast
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Fmt
import com.matgary.app.data.TruckRow
import com.matgary.app.data.db.Customer
import com.matgary.app.ui.components.BarcodeScannerDialog
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

/** Step 1 of a sale: pick what the customer wants from what is on the truck. */
@Composable
fun SaleScreen(truck: List<TruckRow>, cart: SnapshotStateMap<Long, Int>, onCheckout: () -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    var q by remember { mutableStateOf("") }
    val shown = truck.filter { q.isBlank() || it.item.name.contains(q.trim(), ignoreCase = true) || it.item.barcode.contains(q.trim()) }
    val count = cart.values.sum()
    val total = truck.sumOf { (cart[it.item.id] ?: 0) * it.item.sellPrice }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("بيع جديد", onBack)
            var scanning by remember { mutableStateOf(false) }
            val ctx = LocalContext.current
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    q, { q = it }, label = { Text("ابحث بالاسم أو الباركود") }, singleLine = true,
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                )
                TextButton(onClick = { scanning = true }) { Text("مسح", color = c.accent, fontWeight = FontWeight.Bold) }
            }
            if (scanning) BarcodeScannerDialog(
                continuous = true,
                onResult = { code ->
                    val r = truck.firstOrNull { it.item.barcode == code }
                    if (r == null) Toast.makeText(ctx, "الباركود ده مش موجود على العربية", Toast.LENGTH_SHORT).show()
                    else cart[r.item.id] = ((cart[r.item.id] ?: 0) + 1).coerceAtMost(r.qty)
                },
                onDismiss = { scanning = false },
            )
            if (truck.isEmpty()) {
                Text("العربية فاضية. حمّل العربية الأول.", color = c.muted, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.item.id }) { r ->
                        val id = r.item.id
                        val n = cart[id] ?: 0
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(r.item.name, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(Fmt.money(r.item.sellPrice), color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Black)
                                }
                                Text("على العربية: ${qtyText(r.qty, r.item)}", color = c.muted, fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    StepButton("−") { if (n <= 1) cart.remove(id) else cart[id] = n - 1 }
                                    Text("$n", color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.width(44.dp))
                                    StepButton("+") { cart[id] = (n + 1).coerceAtMost(r.qty) }
                                }
                            }
                        }
                    }
                }
            }
            Text("$count قطعة · الإجمالي ${Fmt.money(total)}", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            PrimaryButton("مراجعة وإتمام", Modifier.padding(vertical = 8.dp), enabled = count > 0, onClick = onCheckout)
        }
    }
}

/** Step 2 of a sale: adjust quantity and price, discount, payment type, customer. */
@Composable
fun CheckoutScreen(
    truck: List<TruckRow>,
    cart: SnapshotStateMap<Long, Int>,
    prices: SnapshotStateMap<Long, Double>,
    customers: List<Customer>,
    onAddCustomer: (name: String, phone: String, done: (Long) -> Unit) -> Unit,
    onConfirm: (discount: Double, payment: String, customerId: Long?, paidNow: Double) -> Unit,
    onBack: () -> Unit,
) {
    val c = AppTheme.colors
    val lines = truck.filter { (cart[it.item.id] ?: 0) > 0 }
    var discount by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("CASH") }
    var customerId by remember { mutableStateOf<Long?>(null) }
    var paidNow by remember { mutableStateOf("0") }
    var picking by remember { mutableStateOf(false) }
    fun priceOf(r: TruckRow) = prices[r.item.id] ?: r.item.sellPrice
    val gross = lines.sumOf { (cart[it.item.id] ?: 0) * priceOf(it) }
    val d = (Fmt.num(discount) ?: 0.0).coerceIn(0.0, gross)
    val total = gross - d
    val customer = customers.firstOrNull { it.id == customerId }
    val ready = lines.isNotEmpty() && (payment != "CREDIT" || customer != null)

    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("إتمام البيع", onBack)
            lines.forEach { r ->
                val id = r.item.id
                val n = cart[id] ?: 0
                var priceText by remember(id) { mutableStateOf(Fmt.money(priceOf(r))) }
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(r.item.name, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text(Fmt.money(n * priceOf(r)), color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Black)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            StepButton("−") { if (n <= 1) cart.remove(id) else cart[id] = n - 1 }
                            Text("$n", color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, modifier = Modifier.width(40.dp))
                            StepButton("+") { cart[id] = (n + 1).coerceAtMost(r.qty) }
                            NumField("سعر الوحدة", priceText, Modifier.weight(1f)) { t ->
                                priceText = t
                                Fmt.num(t)?.let { prices[id] = it }
                            }
                        }
                    }
                }
            }
            if (lines.isEmpty()) Text("السلة فاضية.", color = c.muted, fontSize = 14.sp)
            NumField("خصم على الفاتورة", discount, Modifier.padding(top = 4.dp)) { discount = it }
            Text("طريقة الدفع", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("CASH" to "كاش", "WALLET" to "محفظة", "CREDIT" to "أجل").forEach { (k, label) ->
                    FilterChip(selected = payment == k, onClick = { payment = k }, label = { Text(label) })
                }
            }
            if (payment == "CREDIT") {
                OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(14.dp)) {
                    Text(customer?.name ?: "اختار العميل", color = c.accent, fontWeight = FontWeight.Bold)
                }
                NumField("المدفوع دلوقتي", paidNow, Modifier.padding(top = 8.dp)) { paidNow = it }
                val rest = total - (Fmt.num(paidNow) ?: 0.0).coerceIn(0.0, total)
                Text("المتبقي على العميل: ${Fmt.money(rest)}", color = c.warn, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("الإجمالي: ${Fmt.money(total)}", color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.Black)
            PrimaryButton("تأكيد البيع", Modifier.padding(vertical = 12.dp), enabled = ready) {
                onConfirm(d, payment, customer?.id, Fmt.num(paidNow) ?: 0.0)
            }
        }
    }
    if (picking) CustomerDialog(
        customers = customers,
        onPick = { customerId = it; picking = false },
        onNew = { name, phone -> onAddCustomer(name, phone) { id -> customerId = id; picking = false } },
        onDismiss = { picking = false },
    )
}

@Composable
private fun CustomerDialog(customers: List<Customer>, onPick: (Long) -> Unit, onNew: (String, String) -> Unit, onDismiss: () -> Unit) {
    val c = AppTheme.colors
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("اختار العميل") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                customers.forEach { cu ->
                    Text(cu.name + if (cu.phone.isNotBlank()) " · ${cu.phone}" else "", color = c.ink, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(cu.id) }.padding(vertical = 10.dp))
                }
                Text("عميل جديد", color = c.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("الموبايل (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onNew(name, phone) }) { Text("إضافة واختيار") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}
