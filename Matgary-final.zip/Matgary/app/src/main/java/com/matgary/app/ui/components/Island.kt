package com.matgary.app.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class AlertKind { STOCK, EXPIRY, DEBT }

data class IslandAlert(val kind: AlertKind, val title: String, val lines: List<String>, val actionLabel: String)

private fun dotColor(k: AlertKind) = when (k) {
    AlertKind.STOCK -> Color(0xFFF87171)
    AlertKind.EXPIRY -> Color(0xFFFBBF24)
    AlertKind.DEBT -> Color(0xFF67E8F9)
}

/**
 * In-app version of the Dynamic Island: a tiny black pill pops out of the top, springs open,
 * grows into a card when tapped, and shrinks back into the top edge.
 */
@Composable
fun IslandOverlay(alert: IslandAlert?, onAction: (IslandAlert) -> Unit, onDismiss: () -> Unit) {
    if (alert == null) return
    var stage by remember(alert) { mutableIntStateOf(0) } // 0 tiny, 1 pill, 2 card, 3 leaving
    LaunchedEffect(alert) { delay(120); stage = 1 }
    LaunchedEffect(alert, stage) {
        if (stage == 1) { delay(5000); stage = 3 }
        if (stage == 3) { delay(320); onDismiss() }
    }
    val bounce = spring<Float>(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    val fraction by animateFloatAsState(
        when (stage) { 1 -> 0.66f; 2 -> 0.94f; else -> 0.3f }, bounce, label = "islandWidth",
    )
    val radius by animateDpAsState(when (stage) { 2 -> 32.dp; 1 -> 22.dp; else -> 18.dp }, label = "islandRadius")
    val contentAlpha by animateFloatAsState(if (stage == 1 || stage == 2) 1f else 0f, tween(220), label = "islandAlpha")

    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.fillMaxWidth(fraction.coerceIn(0.1f, 1f)).animateContentSize()
                .clip(RoundedCornerShape(radius)).background(Color.Black)
                .clickable(enabled = stage == 1) { stage = 2 }
                .padding(horizontal = if (stage == 2) 18.dp else 14.dp, vertical = if (stage == 2) 16.dp else 9.dp),
        ) {
            Row(Modifier.alpha(contentAlpha), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(if (stage == 2) 14.dp else 10.dp).clip(CircleShape).background(dotColor(alert.kind)))
                Spacer(Modifier.width(10.dp))
                Text(alert.title, color = Color.White, fontSize = if (stage == 2) 16.sp else 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            if (stage == 2) {
                Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    alert.lines.forEach { Text(it, color = Color(0xFFD4D4D8), fontSize = 14.sp) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onAction(alert) }, modifier = Modifier.weight(1f).height(44.dp), shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                    ) { Text(alert.actionLabel, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = { stage = 3 }, modifier = Modifier.weight(1f).height(44.dp), shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A), contentColor = Color.White),
                    ) { Text("تجاهل", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}
