package com.matgary.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class AlertKind { STOCK, EXPIRY, DEBT }

data class IslandAlert(val kind: AlertKind, val title: String, val lines: List<String>, val actionLabel: String)

private fun dotColor(k: AlertKind) = when (k) {
    AlertKind.STOCK -> Color(0xFFF87171)
    AlertKind.EXPIRY -> Color(0xFFFBBF24)
    AlertKind.DEBT -> Color(0xFF67E8F9)
}

/**
 * In-app alert that drops from the top like the iPhone Dynamic Island.
 * It starts as a small black pill, expands when tapped, and hides by itself after 5 seconds if left alone.
 */
@Composable
fun IslandOverlay(alert: IslandAlert?, onAction: (IslandAlert) -> Unit, onDismiss: () -> Unit) {
    if (alert == null) return
    var expanded by remember(alert) { mutableStateOf(false) }
    LaunchedEffect(alert, expanded) {
        if (!expanded) { delay(5000); onDismiss() }
    }
    val fraction by animateFloatAsState(if (expanded) 0.94f else 0.66f, label = "islandWidth")
    val state = remember(alert) { MutableTransitionState(false).apply { targetState = true } }
    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(visibleState = state, enter = slideInVertically { -it * 2 } + fadeIn()) {
            Column(
                Modifier.fillMaxWidth(fraction).animateContentSize()
                    .clip(RoundedCornerShape(if (expanded) 32.dp else 22.dp)).background(Color.Black)
                    .clickable(enabled = !expanded) { expanded = true }
                    .padding(horizontal = 16.dp, vertical = if (expanded) 16.dp else 10.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(if (expanded) 14.dp else 10.dp).clip(CircleShape).background(dotColor(alert.kind)))
                    Spacer(Modifier.width(10.dp))
                    Text(alert.title, color = Color.White, fontSize = if (expanded) 16.sp else 13.sp, fontWeight = FontWeight.Bold)
                }
                if (expanded) {
                    Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        alert.lines.forEach { Text(it, color = Color(0xFFD4D4D8), fontSize = 14.sp) }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onAction(alert) }, modifier = Modifier.weight(1f).height(44.dp), shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        ) { Text(alert.actionLabel, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = onDismiss, modifier = Modifier.weight(1f).height(44.dp), shape = RoundedCornerShape(22.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27272A), contentColor = Color.White),
                        ) { Text("تجاهل", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}
