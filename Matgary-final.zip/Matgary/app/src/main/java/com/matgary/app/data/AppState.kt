package com.matgary.app.data

/** Tiny process-wide flags. */
object AppState {
    /** True while the app screen is visible. Background alerts stay quiet then, because the in-app island already shows them. */
    @Volatile var foreground = false
}
