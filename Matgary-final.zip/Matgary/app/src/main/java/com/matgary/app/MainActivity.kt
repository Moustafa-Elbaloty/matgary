package com.matgary.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.matgary.app.alerts.AlertScheduler
import com.matgary.app.alerts.Notifier
import com.matgary.app.data.AppLock
import com.matgary.app.data.AppState
import com.matgary.app.data.Config
import com.matgary.app.data.AppPrefs
import com.matgary.app.data.BackupManager
import com.matgary.app.data.DaySummary
import com.matgary.app.data.Dates
import com.matgary.app.data.Exporter
import com.matgary.app.data.Fmt
import com.matgary.app.data.Flag
import com.matgary.app.data.InventoryRepo
import com.matgary.app.data.LicenseChecker
import com.matgary.app.data.LicenseResult
import com.matgary.app.data.ReportData
import com.matgary.app.data.SaleInput
import com.matgary.app.data.SecureStore
import com.matgary.app.data.StockValue
import com.matgary.app.data.db.Item
import com.matgary.app.data.flags
import com.matgary.app.ui.components.AlertKind
import com.matgary.app.ui.components.IslandAlert
import com.matgary.app.ui.components.IslandOverlay
import com.matgary.app.ui.screens.ActivationScreen
import com.matgary.app.ui.screens.BackupScreen
import com.matgary.app.ui.screens.LockScreen
import com.matgary.app.ui.screens.CheckoutScreen
import com.matgary.app.ui.screens.CloseDayScreen
import com.matgary.app.ui.screens.CustomerDebtScreen
import com.matgary.app.ui.screens.DebtsScreen
import com.matgary.app.ui.screens.ExpensesScreen
import com.matgary.app.ui.screens.HomeDest
import com.matgary.app.ui.screens.HomeScreen
import com.matgary.app.ui.screens.InventoryScreen
import com.matgary.app.ui.screens.ItemDetailScreen
import com.matgary.app.ui.screens.ItemFormScreen
import com.matgary.app.ui.screens.LoadTruckScreen
import com.matgary.app.ui.screens.OwnerGateScreen
import com.matgary.app.ui.screens.OwnerPanelScreen
import com.matgary.app.ui.screens.REPORT_RANGES
import com.matgary.app.ui.screens.ReportsScreen
import com.matgary.app.ui.screens.ReturnsWasteScreen
import com.matgary.app.ui.screens.SaleScreen
import com.matgary.app.ui.screens.SettingsScreen
import com.matgary.app.ui.screens.SplashScreen
import com.matgary.app.ui.screens.StoreSetupScreen
import com.matgary.app.ui.screens.TruckCountScreen
import com.matgary.app.ui.screens.TruckScreen
import com.matgary.app.ui.theme.MatgaryTheme
import com.matgary.app.ui.theme.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.time.LocalDate

private enum class Screen {
    SPLASH, ACTIVATION, OWNER_GATE, OWNER_PANEL, STORE, HOME,
    INVENTORY, ITEM_FORM, ITEM_DETAIL, TRUCK, LOAD, SALE, CHECKOUT, RETURNS,
    DEBTS, DEBT_DETAIL, EXPENSES, CLOSE, COUNT, REPORTS, SETTINGS, LOCK, BACKUP,
}

class MainActivity : FragmentActivity() {

    private val secure by lazy { SecureStore(applicationContext) }
    private val restoreUri = mutableStateOf<Uri?>(null)
    private val lockRequest = mutableStateOf(false)
    private var stoppedAt = 0L
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { restoreUri.value = it }
    private val pendingDest = mutableStateOf<String?>(null)
    private val permTick = mutableIntStateOf(0)
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { openOverlaySettings() }

    private fun openOverlaySettings() {
        if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    /** Asks for notification permission first, then for "display over other apps". */
    private fun requestAlertPermissions() {
        Notifier.ensureChannels(this)
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.canNotify(this)) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else openOverlaySettings()
    }

    private fun versionLabel(): String = try {
        val p = packageManager.getPackageInfo(packageName, 0)
        val code = if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else @Suppress("DEPRECATION") p.versionCode.toLong()
        "الإصدار ${p.versionName} · بناء $code"
    } catch (e: Exception) { "" }

    private fun handleIntent(i: Intent?) { i?.getStringExtra("dest")?.let { pendingDest.value = it } }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }
    override fun onResume() { super.onResume(); permTick.intValue++ }

    // Ask for the PIN again when the app comes back after more than a minute in the background.
    override fun onStop() { super.onStop(); AppState.foreground = false; stoppedAt = System.currentTimeMillis() }
    override fun onStart() {
        super.onStart()
        AppState.foreground = true
        if (stoppedAt != 0L && System.currentTimeMillis() - stoppedAt > 60_000 && AppLock.isEnabled(secure)) lockRequest.value = true
    }

    private fun canBiometric() =
        BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    private fun promptBiometric(onOk: () -> Unit) {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("فتح متجري").setNegativeButtonText("استخدم الـ PIN")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).build()
        )
    }

    private fun restartApp() {
        val launch = packageManager.getLaunchIntentForPackage(packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(launch)
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun licenseText(owner: Boolean): String {
        if (owner) return "حساب المالك"
        if (!Config.REQUIRE_ACTIVATION) return "وضع التجربة (بدون تفعيل)"
        return when (val st = LicenseChecker.status(applicationContext)) {
            is LicenseResult.Valid ->
                if (st.expiryDay == 0) "ترخيص دائم" else "مفعّل حتى ${LocalDate.ofEpochDay(st.expiryDay.toLong())}"
            is LicenseResult.Invalid -> ""
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = AppPrefs(applicationContext)
        handleIntent(intent)
        Notifier.ensureChannels(this)
        if (prefs.alertsOn) AlertScheduler.schedule(this)
        // The encrypted database is opened only when first needed (after activation).
        val repo by lazy { InventoryRepo(applicationContext, secure) }

        setContent {
            val scope = rememberCoroutineScope()
            var mode by remember { mutableStateOf(prefs.themeMode) }
            var storeName by remember { mutableStateOf(prefs.storeName) }
            var screen by remember { mutableStateOf(Screen.SPLASH) }
            var owner by remember { mutableStateOf(false) }
            var notice by remember { mutableStateOf<String?>(null) }
            var selectedId by remember { mutableLongStateOf(0L) }
            var selectedCustomer by remember { mutableLongStateOf(0L) }
            var editing by remember { mutableStateOf<Item?>(null) }
            var closeDay by remember { mutableIntStateOf(Dates.today()) }
            var refresh by remember { mutableIntStateOf(0) }
            var lastBackup by remember { mutableIntStateOf(prefs.lastBackupDay) }
            var lockEnabled by remember { mutableStateOf(AppLock.isEnabled(secure)) }
            var bioOn by remember { mutableStateOf(AppLock.bioEnabled(secure)) }
            var returnTo by remember { mutableStateOf<Screen?>(null) }
            var islandDismissed by remember { mutableStateOf(setOf<String>()) }
            var alertsOn by remember { mutableStateOf(prefs.alertsOn) }
            val cart = remember { mutableStateMapOf<Long, Int>() }
            val prices = remember { mutableStateMapOf<Long, Double>() }
            val next = { if (storeName.isBlank()) Screen.STORE else Screen.HOME }

            // The phone's own back button goes one screen back instead of leaving the app.
            val tick = permTick.intValue
            val parent: Screen? = when (screen) {
                Screen.SPLASH, Screen.ACTIVATION, Screen.LOCK, Screen.STORE, Screen.HOME -> null
                Screen.INVENTORY, Screen.TRUCK, Screen.SALE, Screen.RETURNS, Screen.DEBTS, Screen.EXPENSES,
                Screen.CLOSE, Screen.REPORTS, Screen.SETTINGS -> Screen.HOME
                Screen.ITEM_FORM -> if (editing == null) Screen.INVENTORY else Screen.ITEM_DETAIL
                Screen.ITEM_DETAIL -> Screen.INVENTORY
                Screen.LOAD -> Screen.TRUCK
                Screen.CHECKOUT -> Screen.SALE
                Screen.DEBT_DETAIL -> Screen.DEBTS
                Screen.COUNT -> Screen.CLOSE
                Screen.BACKUP -> Screen.SETTINGS
                Screen.OWNER_GATE, Screen.OWNER_PANEL -> if (Config.REQUIRE_ACTIVATION) Screen.ACTIVATION else Screen.SETTINGS
            }
            BackHandler(enabled = parent != null) { parent?.let { screen = it } }

            // Opened from an alert (island pill or notification): jump to the right screen.
            val dest = pendingDest.value
            LaunchedEffect(dest, screen) {
                if (dest != null && screen !in setOf(Screen.SPLASH, Screen.ACTIVATION, Screen.OWNER_GATE, Screen.OWNER_PANEL, Screen.LOCK, Screen.STORE)) {
                    pendingDest.value = null
                    screen = if (dest == "DEBTS") Screen.DEBTS else Screen.INVENTORY
                }
            }

            val lockNow = lockRequest.value
            LaunchedEffect(lockNow) {
                if (lockNow) {
                    lockRequest.value = false
                    if (screen !in setOf(Screen.SPLASH, Screen.ACTIVATION, Screen.OWNER_GATE, Screen.OWNER_PANEL, Screen.LOCK, Screen.STORE)) {
                        returnTo = screen
                        screen = Screen.LOCK
                    }
                }
            }

            MatgaryTheme(mode) {
                when (screen) {
                    Screen.SPLASH -> SplashScreen {
                        if (!Config.REQUIRE_ACTIVATION) { screen = if (lockEnabled) Screen.LOCK else next(); return@SplashScreen }
                        when (val st = LicenseChecker.status(applicationContext)) {
                            is LicenseResult.Valid -> screen = if (lockEnabled) Screen.LOCK else next()
                            is LicenseResult.Invalid -> { notice = st.message.ifBlank { null }; screen = Screen.ACTIVATION }
                        }
                    }
                    Screen.ACTIVATION -> ActivationScreen(
                        deviceCode = LicenseChecker.deviceCode(applicationContext),
                        notice = notice,
                        verify = { code ->
                            when (val r = LicenseChecker.verify(applicationContext, code)) {
                                is LicenseResult.Valid -> null
                                is LicenseResult.Invalid -> r.message
                            }
                        },
                        onActivated = { screen = next() },
                        onOwnerEntry = { screen = Screen.OWNER_GATE },
                    )
                    Screen.OWNER_GATE -> OwnerGateScreen(
                        secure = secure,
                        onUnlocked = { owner = true; screen = Screen.OWNER_PANEL },
                        onBack = { screen = if (Config.REQUIRE_ACTIVATION) Screen.ACTIVATION else Screen.SETTINGS },
                    )
                    Screen.OWNER_PANEL -> OwnerPanelScreen(
                        onOpenApp = { screen = next() },
                        onExit = { owner = false; screen = if (Config.REQUIRE_ACTIVATION) Screen.ACTIVATION else Screen.SETTINGS },
                    )
                    Screen.STORE -> StoreSetupScreen { prefs.storeName = it; storeName = it; screen = Screen.HOME }

                    Screen.HOME -> {
                        val rows by remember { repo.rows() }.collectAsState(emptyList())
                        val debts by remember { repo.debts() }.collectAsState(emptyList())
                        val todaySales by remember { repo.salesToday() }.collectAsState(0.0)
                        val today by produceState<DaySummary?>(null, todaySales, rows) {
                            value = repo.summary(Dates.today(), Dates.today())
                        }
                        val d = Dates.today()
                        val flagged = rows.map { it.flags(Dates.WARN_DAYS, d) }
                        val alerts = remember(rows, debts) {
                            buildList<IslandAlert> {
                                val low = rows.filter { r -> r.flags(Dates.WARN_DAYS, d).any { it == Flag.OUT || it == Flag.LOW } }
                                if (low.isNotEmpty()) add(IslandAlert(AlertKind.STOCK, "${low.size} أصناف خلصت أو ناقصة", low.take(3).map { "${it.item.name} · الرصيد ${it.stock}" }, "عرض المخزن"))
                                val exp = rows.filter { r -> r.flags(Dates.WARN_DAYS, d).any { it == Flag.EXPIRED || it == Flag.EXPIRING } }
                                if (exp.isNotEmpty()) add(IslandAlert(AlertKind.EXPIRY, "${exp.size} أصناف قربت صلاحيتها", exp.take(3).map { r ->
                                    val e = r.nearestExpiry ?: d
                                    "${r.item.name} · " + if (e < d) "منتهي" else "باقي ${e - d} يوم"
                                }, "عرض المخزن"))
                                val late = debts.filter { r -> r.oldestOpenDay?.let { d - it > Dates.OVERDUE_DAYS } == true }
                                if (late.isNotEmpty()) add(IslandAlert(AlertKind.DEBT, "${late.size} عملاء متأخرين في الدفع", late.take(3).map { "${it.customer.name} · ${Fmt.money(it.balance)}" }, "المديونيات"))
                            }
                        }
                        val island = alerts.firstOrNull { it.title !in islandDismissed }
                        Box {
                        HomeScreen(
                            storeName = storeName, licenseText = licenseText(owner), today = today,
                            stockAlerts = flagged.count { f -> f.any { it == Flag.OUT || it == Flag.LOW } },
                            expiryAlerts = flagged.count { f -> f.any { it == Flag.EXPIRED || it == Flag.EXPIRING } },
                            debtors = debts.size,
                            backupDue = lastBackup == 0 || Dates.today() - lastBackup > 7,
                        ) { dest ->
                            screen = when (dest) {
                                HomeDest.SALE -> Screen.SALE
                                HomeDest.TRUCK -> Screen.TRUCK
                                HomeDest.INVENTORY -> Screen.INVENTORY
                                HomeDest.DEBTS -> Screen.DEBTS
                                HomeDest.RETURNS -> Screen.RETURNS
                                HomeDest.EXPENSES -> Screen.EXPENSES
                                HomeDest.CLOSE -> { closeDay = Dates.today(); Screen.CLOSE }
                                HomeDest.REPORTS -> Screen.REPORTS
                                HomeDest.SETTINGS -> Screen.SETTINGS
                                HomeDest.BACKUP -> Screen.BACKUP
                            }
                        }
                        IslandOverlay(
                            alert = island,
                            onAction = { a ->
                                islandDismissed = islandDismissed + a.title
                                screen = if (a.kind == AlertKind.DEBT) Screen.DEBTS else Screen.INVENTORY
                            },
                            onDismiss = { island?.let { islandDismissed = islandDismissed + it.title } },
                        )
                        }
                    }
                    Screen.SETTINGS -> SettingsScreen(
                        storeName = storeName, mode = mode, isOwner = owner || !Config.REQUIRE_ACTIVATION,
                        versionLabel = versionLabel(),
                        onUpdate = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Config.UPDATE_URL))) },
                        alertsOn = alertsOn,
                        overlayGranted = tick >= 0 && Settings.canDrawOverlays(this@MainActivity),
                        notifGranted = tick >= 0 && Notifier.canNotify(this@MainActivity),
                        onAlertsToggle = { on ->
                            alertsOn = on; prefs.alertsOn = on
                            if (on) { requestAlertPermissions(); AlertScheduler.schedule(this@MainActivity) } else AlertScheduler.cancel(this@MainActivity)
                        },
                        onFixPermissions = { requestAlertPermissions() },
                        onTestAlert = {
                            requestAlertPermissions()
                            AlertScheduler.testNow(this@MainActivity)
                            Toast.makeText(applicationContext, "اضغط زر الهوم وانتظر ٦ ثواني", Toast.LENGTH_LONG).show()
                        },
                        lockEnabled = lockEnabled, bioAvailable = canBiometric(), bioEnabled = bioOn,
                        onMode = { mode = it; prefs.themeMode = it },
                        onStoreName = { prefs.storeName = it; storeName = it },
                        onSetPin = { pin -> scope.launch { withContext(Dispatchers.Default) { AppLock.set(secure, pin) }; lockEnabled = true } },
                        onDisableLock = { pin, done ->
                            scope.launch {
                                val ok = withContext(Dispatchers.Default) { AppLock.check(secure, pin) }
                                if (ok) { AppLock.clear(secure); lockEnabled = false; bioOn = false }
                                done(ok)
                            }
                        },
                        onBio = { on -> AppLock.setBio(secure, on); bioOn = on },
                        onBackup = { screen = Screen.BACKUP },
                        onOwner = { screen = if (owner) Screen.OWNER_PANEL else Screen.OWNER_GATE },
                        onBack = { screen = Screen.HOME },
                    )
                    Screen.LOCK -> LockScreen(
                        pinLength = AppLock.pinLength(secure),
                        bioEnabled = bioOn && canBiometric(),
                        onSubmit = { pin, done ->
                            scope.launch {
                                val ok = withContext(Dispatchers.Default) { AppLock.check(secure, pin) }
                                done(ok)
                                if (ok) { screen = returnTo ?: next(); returnTo = null }
                            }
                        },
                        onBio = { promptBiometric { screen = returnTo ?: next(); returnTo = null } },
                    )
                    Screen.BACKUP -> {
                        val picked by restoreUri
                        BackupScreen(
                            lastBackupDay = lastBackup, pickedName = picked?.lastPathSegment,
                            onCreate = { pw ->
                                scope.launch {
                                    try {
                                        repo.checkpoint()
                                        val bytes = withContext(Dispatchers.Default) { BackupManager.create(secure, repo.dbFile(), pw, storeName, mode.name) }
                                        Exporter.shareBytes(this@MainActivity, "matgary-backup-${Dates.fmt(Dates.today())}.mtjb", bytes)
                                        lastBackup = Dates.today(); prefs.lastBackupDay = lastBackup
                                    } catch (e: Exception) {
                                        Toast.makeText(applicationContext, "ماقدرناش نعمل النسخة", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            onPick = { picker.launch(arrayOf("*/*")) },
                            onRestore = { pw, done ->
                                scope.launch {
                                    val result = withContext(Dispatchers.Default) {
                                        runCatching { BackupManager.open(contentResolver.openInputStream(restoreUri.value!!)!!.use { it.readBytes() }, pw) }
                                    }
                                    result.onSuccess { r ->
                                        repo.close()
                                        BackupManager.writeDatabase(applicationContext, r)
                                        secure.put("db_pass", r.passphrase)
                                        prefs.storeName = r.storeName
                                        runCatching { prefs.themeMode = ThemeMode.valueOf(r.theme) }
                                        restartApp()
                                    }.onFailure {
                                        done(if (it is IllegalStateException) "النسخة دي من إصدار أحدث من التطبيق." else "كلمة السر غلط أو الملف مش نسخة متجري.")
                                    }
                                }
                            },
                            onBack = { screen = Screen.SETTINGS },
                        )
                    }

                    Screen.INVENTORY -> {
                        val rows by remember { repo.rows() }.collectAsState(emptyList())
                        InventoryScreen(
                            rows = rows,
                            onAdd = { editing = null; screen = Screen.ITEM_FORM },
                            onOpen = { selectedId = it; screen = Screen.ITEM_DETAIL },
                            onBack = { screen = Screen.HOME },
                        )
                    }
                    Screen.ITEM_FORM -> ItemFormScreen(
                        initial = editing,
                        onSave = { item -> scope.launch { selectedId = repo.save(item); screen = Screen.ITEM_DETAIL } },
                        onCancel = { screen = if (editing == null) Screen.INVENTORY else Screen.ITEM_DETAIL },
                    )
                    Screen.ITEM_DETAIL -> {
                        val rows by remember { repo.rows() }.collectAsState(emptyList())
                        val batches by remember(selectedId) { repo.batches(selectedId) }.collectAsState(emptyList())
                        val moves by remember(selectedId) { repo.movements(selectedId) }.collectAsState(emptyList())
                        val row = rows.firstOrNull { it.item.id == selectedId }
                        if (row != null) {
                            ItemDetailScreen(
                                item = row.item, stock = row.stock, batches = batches, moves = moves,
                                onReceive = { units, cost, expiry -> scope.launch { repo.receive(row.item.id, units, cost, expiry) } },
                                onWaste = { units, reason -> scope.launch { repo.consume(row.item.id, units, "WASTE", reason) } },
                                onEdit = { editing = row.item; screen = Screen.ITEM_FORM },
                                onDelete = { scope.launch { repo.delete(row.item.id); screen = Screen.INVENTORY } },
                                onBack = { screen = Screen.INVENTORY },
                            )
                        } else if (rows.isNotEmpty()) {
                            LaunchedEffect(Unit) { screen = Screen.INVENTORY }
                        }
                    }

                    Screen.TRUCK -> {
                        val truck by remember { repo.truckRows() }.collectAsState(emptyList())
                        TruckScreen(
                            rows = truck,
                            onLoad = { screen = Screen.LOAD },
                            onUnload = { scope.launch { repo.returnAllToWarehouse() } },
                            onBack = { screen = Screen.HOME },
                        )
                    }
                    Screen.LOAD -> {
                        val rows by remember { repo.rows() }.collectAsState(emptyList())
                        val last by remember { repo.lastLoadLines() }.collectAsState(emptyList())
                        LoadTruckScreen(
                            rows = rows, lastLoad = last,
                            onConfirm = { lines -> scope.launch { if (repo.loadTruck(lines)) screen = Screen.TRUCK } },
                            onBack = { screen = Screen.TRUCK },
                        )
                    }

                    Screen.SALE -> {
                        val truck by remember { repo.truckRows() }.collectAsState(emptyList())
                        SaleScreen(truck, cart, onCheckout = { screen = Screen.CHECKOUT }, onBack = { screen = Screen.HOME })
                    }
                    Screen.CHECKOUT -> {
                        val truck by remember { repo.truckRows() }.collectAsState(emptyList())
                        val customers by remember { repo.customers() }.collectAsState(emptyList())
                        CheckoutScreen(
                            truck = truck, cart = cart, prices = prices, customers = customers,
                            onAddCustomer = { n, p, done -> scope.launch { done(repo.addCustomer(n, p)) } },
                            onConfirm = { discount, payment, customerId, paidNow ->
                                val lines = cart.map { (id, q) ->
                                    SaleInput(id, q, prices[id] ?: truck.firstOrNull { it.item.id == id }?.item?.sellPrice ?: 0.0)
                                }
                                scope.launch {
                                    if (repo.sell(lines, customerId, payment, discount, paidNow) != null) {
                                        cart.clear(); prices.clear()
                                        Toast.makeText(applicationContext, "تم البيع", Toast.LENGTH_SHORT).show()
                                        screen = Screen.SALE
                                    } else {
                                        Toast.makeText(applicationContext, "الكمية على العربية مش كفاية", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            onBack = { screen = Screen.SALE },
                        )
                    }
                    Screen.RETURNS -> {
                        val rows by remember { repo.rows() }.collectAsState(emptyList())
                        val truck by remember { repo.truckRows() }.collectAsState(emptyList())
                        ReturnsWasteScreen(
                            allItems = rows, truck = truck,
                            onReturn = { id, q, refund, good -> scope.launch { repo.customerReturn(id, q, refund, good) } },
                            onWaste = { id, q, reason -> scope.launch { repo.wasteFromTruck(id, q, reason) } },
                            onBack = { screen = Screen.HOME },
                        )
                    }

                    Screen.DEBTS -> {
                        val rows by remember { repo.debts() }.collectAsState(emptyList())
                        DebtsScreen(
                            rows = rows,
                            onOpen = { selectedCustomer = it; screen = Screen.DEBT_DETAIL },
                            onAddCustomer = { n, p -> scope.launch { repo.addCustomer(n, p) } },
                            onBack = { screen = Screen.HOME },
                        )
                    }
                    Screen.DEBT_DETAIL -> {
                        val rows by remember { repo.debts() }.collectAsState(emptyList())
                        val customers by remember { repo.customers() }.collectAsState(emptyList())
                        val ledger by remember(selectedCustomer) { repo.ledger(selectedCustomer) }.collectAsState(emptyList())
                        val customer = customers.firstOrNull { it.id == selectedCustomer }
                        if (customer != null) {
                            CustomerDebtScreen(
                                customer = customer,
                                balance = rows.firstOrNull { it.customer.id == customer.id }?.balance ?: 0.0,
                                ledger = ledger, storeName = storeName,
                                onPay = { amount -> scope.launch { repo.addPayment(customer.id, amount) } },
                                onSaveCustomer = { n, p -> scope.launch { repo.updateCustomer(customer.copy(name = n, phone = p)) } },
                                onBack = { screen = Screen.DEBTS },
                            )
                        }
                    }

                    Screen.EXPENSES -> {
                        val list by remember { repo.expenses() }.collectAsState(emptyList())
                        val monthStart = remember { LocalDate.now().withDayOfMonth(1).toEpochDay().toInt() }
                        val monthTotal by produceState(0.0, list) { value = repo.summary(monthStart, Dates.today()).expenses }
                        ExpensesScreen(
                            expenses = list, monthTotal = monthTotal,
                            onAdd = { cat, amount, note -> scope.launch { repo.addExpense(cat, amount, note) } },
                            onDelete = { id -> scope.launch { repo.deleteExpense(id) } },
                            onBack = { screen = Screen.HOME },
                        )
                    }
                    Screen.CLOSE -> {
                        val summary by produceState<DaySummary?>(null, closeDay, refresh) { value = null; value = repo.summary(closeDay, closeDay) }
                        val closing by remember(closeDay) { repo.closingFor(closeDay) }.collectAsState(null)
                        CloseDayScreen(
                            day = closeDay, summary = summary, closing = closing,
                            onDay = { closeDay = it },
                            onSave = { actual, note -> scope.launch { repo.saveClosing(closeDay, summary?.expectedCash ?: 0.0, actual, note) } },
                            onCount = { screen = Screen.COUNT },
                            onBack = { screen = Screen.HOME },
                        )
                    }
                    Screen.COUNT -> {
                        val truck by remember { repo.truckRows() }.collectAsState(emptyList())
                        TruckCountScreen(
                            rows = truck,
                            onApply = { actual -> scope.launch { repo.applyTruckCount(actual); refresh++; screen = Screen.CLOSE } },
                            onBack = { screen = Screen.CLOSE },
                        )
                    }

                    Screen.REPORTS -> {
                        var range by remember { mutableIntStateOf(1) }
                        val rows by remember { repo.rows() }.collectAsState(emptyList())
                        val report by produceState<ReportData?>(null, range) { value = null; value = repo.report(REPORT_RANGES[range].second) }
                        val stock by produceState<StockValue?>(null, rows) { value = repo.stockValue() }
                        val stagnant by produceState(emptyList<Item>(), rows) {
                            val inStock = rows.filter { it.stock > 0 }.map { it.item.id }.toSet()
                            value = repo.stagnantItems(Dates.today() - 30).filter { it.id in inStock }
                        }
                        val label = REPORT_RANGES[range].first
                        ReportsScreen(
                            rangeIndex = range, onRange = { range = it }, report = report, stock = stock, stagnant = stagnant,
                            onPdf = { report?.let { Exporter.sharePdf(this@MainActivity, "report-${Dates.fmt(it.to)}.pdf", Exporter.reportLines(storeName, label, it)) } },
                            onCsv = { report?.let { Exporter.shareCsv(this@MainActivity, "report-${Dates.fmt(it.to)}.csv", Exporter.reportLines(storeName, label, it)) } },
                            onBack = { screen = Screen.HOME },
                        )
                    }
                }
            }
        }
    }
}
