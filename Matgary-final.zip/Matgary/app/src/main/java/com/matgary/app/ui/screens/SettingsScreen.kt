package com.matgary.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme
import com.matgary.app.ui.theme.ThemeMode

@Composable
fun SettingsScreen(
    storeName: String, mode: ThemeMode, isOwner: Boolean,
    lockEnabled: Boolean, bioAvailable: Boolean, bioEnabled: Boolean,
    onMode: (ThemeMode) -> Unit, onStoreName: (String) -> Unit,
    onSetPin: (String) -> Unit, onDisableLock: (String, (Boolean) -> Unit) -> Unit, onBio: (Boolean) -> Unit,
    onBackup: () -> Unit, onOwner: () -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    var dialog by remember { mutableIntStateOf(0) } // 1 store name, 2 set PIN, 3 turn lock off
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("الإعدادات", onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("اسم المتجر", color = c.muted, fontSize = 12.sp)
                        Text(storeName, color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { dialog = 1 }) { Text("تعديل", color = c.accent) }
                }
            }
            Text("المظهر", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
            ThemeMode.entries.forEach { m ->
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable { onMode(m) }) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = m == mode, onClick = { onMode(m) })
                        Text(m.label, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
            Text("الأمان", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (lockEnabled) "قفل التطبيق شغال" else "قفل التطبيق مقفول", color = if (lockEnabled) c.good else c.muted, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    if (!lockEnabled) {
                        PrimaryButton("تفعيل القفل بـ PIN") { dialog = 2 }
                    } else {
                        if (bioAvailable) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("الفتح بالبصمة", color = c.ink, fontSize = 15.sp)
                            Switch(checked = bioEnabled, onCheckedChange = onBio)
                        }
                        TextButton(onClick = { dialog = 3 }) { Text("إلغاء القفل", color = c.danger) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            PrimaryButton("النسخ الاحتياطي والاسترجاع", onClick = onBackup)
            if (isOwner) {
                Spacer(Modifier.height(12.dp))
                PrimaryButton("لوحة المالك", onClick = onOwner)
            }
            Text("تطوير: مصطفى البلوطي · الإصدار 1.0", color = c.muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 24.dp))
        }
    }
    when (dialog) {
        1 -> {
            var name by remember { mutableStateOf(storeName) }
            AlertDialog(
                onDismissRequest = { dialog = 0 }, title = { Text("اسم المتجر") },
                text = { OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
                confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onStoreName(name.trim()); dialog = 0 }) { Text("حفظ") } },
                dismissButton = { TextButton(onClick = { dialog = 0 }) { Text("إلغاء") } },
            )
        }
        2 -> {
            var a by remember { mutableStateOf("") }
            var b by remember { mutableStateOf("") }
            val ok = a.length in 4..6 && a.all { it.isDigit() } && a == b
            AlertDialog(
                onDismissRequest = { dialog = 0 }, title = { Text("PIN جديد") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("من ٤ لـ ٦ أرقام", fontSize = 12.sp)
                        OutlinedTextField(a, { a = it.filter(Char::isDigit).take(6) }, label = { Text("الـ PIN") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                        OutlinedTextField(b, { b = it.filter(Char::isDigit).take(6) }, label = { Text("أعد كتابته") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    }
                },
                confirmButton = { TextButton(enabled = ok, onClick = { onSetPin(a); dialog = 0 }) { Text("تفعيل") } },
                dismissButton = { TextButton(onClick = { dialog = 0 }) { Text("إلغاء") } },
            )
        }
        3 -> {
            var pin by remember { mutableStateOf("") }
            var wrong by remember { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { dialog = 0 }, title = { Text("إلغاء القفل") },
                text = {
                    Column {
                        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6); wrong = false }, label = { Text("اكتب الـ PIN الحالي") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                        if (wrong) Text("الـ PIN غلط", color = c.danger, fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton(enabled = pin.length >= 4, onClick = { onDisableLock(pin) { ok -> if (ok) dialog = 0 else wrong = true } }) { Text("إلغاء القفل") } },
                dismissButton = { TextButton(onClick = { dialog = 0 }) { Text("رجوع") } },
            )
        }
    }
}
