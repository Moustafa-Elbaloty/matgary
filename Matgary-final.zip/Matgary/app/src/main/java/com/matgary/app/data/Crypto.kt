package com.matgary.app.data

import android.util.Base64
import java.security.MessageDigest

object Crypto {
    private const val FLAGS = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP

    fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)
    fun toHex(b: ByteArray): String = b.joinToString("") { "%02X".format(it) }
    fun fromHex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    fun b64(b: ByteArray): String = Base64.encodeToString(b, FLAGS)
    fun unb64(s: String): ByteArray = Base64.decode(s, FLAGS)
}
