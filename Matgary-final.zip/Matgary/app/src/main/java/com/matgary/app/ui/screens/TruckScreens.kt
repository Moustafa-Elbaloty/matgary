package com.matgary.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Dates
import com.matgary.app.data.Fmt
import com.matgary.app.data.ItemRow
import com.matgary.app.data.TruckRow
import com.matgary.app.data.db.LoadLine
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

@Composable
fun TruckScreen(rows: List<TruckRow>, onLoad: () -> Unit, onUnload: () -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    var confirm by remember { mutableStateOf(false) }
    val pieces = rows.sumOf { it.qty }
    val value = rows.sumOf { it.qty * it.item.sellPrice }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("العربية", onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("على العربية دلوقتي", color = c.muted, fontSize = 13.sp)
                    Text("${rows.size} صنف · $pieces قطعة", color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("قيمة البيع المتوقعة: ${Fmt.money(value)}", color = c.muted, fontSize = 13.sp)
                }
            }
            if (rows.isEmpty()) {
                Text("العربية فاضية. اضغط \"تحميل العربية\" وابدأ يومك.", color = c.muted, fontSize = 14.sp,
                    modifier = Modifier.weight(1f).padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f).padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows, key = { it.item.id }) { r ->
                        GlassCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Text(r.item.name, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text(qtyText(r.qty, r.item), color = c.muted, fontSize = 13.sp)
                                }
                                val e = r.nearestExpiry
                                when {
                                    e == null -> {}
                                    e < today -> Tag("منتهي", c.danger)
                                    e - today <= Dates.WARN_DAYS -> Tag("باقي ${e - today} يوم", c.warn)
                                }
                            }
                        }
                    }
                }
            }
            PrimaryButton("تحميل العربية", Modifier.padding(top = 12.dp), onClick = onLoad)
            TextButton(onClick = { confirm = true }, enabled = rows.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Text("إرجاع المتبقي للمخزن", color = if (rows.isNotEmpty()) c.warn else c.muted)
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("إرجاع كل اللي على العربية؟") },
        text = { Text("كل الأصناف هترجع للمخزن بنفس تواريخ صلاحيتها وتكلفتها.") },
        confirmButton = { TextButton(onClick = { confirm = false; onUnload() }) { Text("إرجاع") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } },
    )
}

@Composable
fun LoadTruckScreen(rows: List<ItemRow>, lastLoad: List<LoadLine>, onConfirm: (List<Pair<Long, Int>>) -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val avail = rows.filter { it.stock > 0 }
    val qty = remember { mutableStateMapOf<Long, Int>() }
    var q by remember { mutableStateOf("") }
    val shown = avail.filter { q.isBlank() || it.item.name.contains(q.trim(), ignoreCase = true) || it.item.barcode.contains(q.trim()) }
    val totalItems = qty.count { it.value > 0 }
    val totalPieces = qty.values.sum()
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("تحميل العربية", onBack)
            OutlinedTextField(
                q, { q = it }, label = { Text("ابحث عن صنف") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
            )
            if (lastLoad.isNotEmpty()) TextButton(onClick = {
                qty.clear()
                lastLoad.forEach { l ->
                    val a = avail.firstOrNull { it.item.id == l.itemId }?.stock ?: 0
                    if (a > 0) qty[l.itemId] = minOf(l.qty, a)
                }
            }) { Text("تكرار آخر تحميل", color = c.accent) }
            if (avail.isEmpty()) {
                Text("مفيش بضاعة في المخزن. استلم بضاعة الأول من شاشة المخزن.", color = c.muted, fontSize = 14.sp,
                    modifier = Modifier.weight(1f).padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.item.id }) { r ->
                        val n = qty[r.item.id] ?: 0
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(r.item.name, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Text("المتاح: ${qtyText(r.stock, r.item)}", color = c.muted, fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    StepButton("−") { qty[r.item.id] = (n - 1).coerceAtLeast(0) }
                                    Text("$n", color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Black,
                                        textAlign = TextAlign.Center, modifier = Modifier.width(44.dp))
                                    StepButton("+") { qty[r.item.id] = (n + 1).coerceAtMost(r.stock) }
                                    if (r.item.packSize > 1) OutlinedButton(
                                        onClick = { qty[r.item.id] = (n + r.item.packSize).coerceAtMost(r.stock) },
                                        modifier = Modifier.size(width = 96.dp, height = 44.dp), shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(0.dp),
                                    ) { Text("+ كرتونة", color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                    }
                }
            }
            Text("$totalItems صنف · $totalPieces قطعة", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 8.dp))
            PrimaryButton("تأكيد التحميل", Modifier.padding(vertical = 8.dp), enabled = totalPieces > 0) {
                onConfirm(qty.filter { it.value > 0 }.map { it.key to it.value })
            }
        }
    }
}

@Composable
internal fun StepButton(label: String, onClick: () -> Unit) {
    val c = AppTheme.colors
    OutlinedButton(onClick = onClick, modifier = Modifier.size(44.dp), shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(0.dp)) {
        Text(label, color = c.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}
