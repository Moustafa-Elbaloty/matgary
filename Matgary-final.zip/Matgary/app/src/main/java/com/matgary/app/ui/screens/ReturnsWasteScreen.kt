package com.matgary.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Fmt
import com.matgary.app.data.ItemRow
import com.matgary.app.data.TruckRow
import com.matgary.app.data.db.Item
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

/** Two jobs on one screen: goods a customer brings back, and goods lost on the truck. */
@Composable
fun ReturnsWasteScreen(
    allItems: List<ItemRow>,
    truck: List<TruckRow>,
    onReturn: (itemId: Long, qty: Int, refund: Double, good: Boolean) -> Unit,
    onWaste: (itemId: Long, qty: Int, reason: String) -> Unit,
    onBack: () -> Unit,
) {
    val c = AppTheme.colors
    var tab by remember { mutableIntStateOf(0) }
    var item by remember { mutableStateOf<Item?>(null) }
    var picking by remember { mutableStateOf(false) }
    var qty by remember { mutableStateOf("") }
    var good by remember { mutableStateOf(true) }
    var refund by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("انتهاء صلاحية") }
    var done by remember { mutableStateOf(false) }
    val n = Fmt.num(qty)?.toInt() ?: 0
    val onTruck = truck.firstOrNull { it.item.id == item?.id }?.qty ?: 0
    val source = if (tab == 0) allItems.map { it.item } else truck.map { it.item }

    fun reset() { item = null; qty = ""; refund = ""; done = true }

    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("مرتجع وهالك", onBack)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = tab == 0, onClick = { tab = 0; item = null; done = false }, label = { Text("مرتجع من زبون") })
                FilterChip(selected = tab == 1, onClick = { tab = 1; item = null; done = false }, label = { Text("هالك على العربية") })
            }
            GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Text(item?.name ?: "اختار الصنف", color = c.accent, fontWeight = FontWeight.Bold)
                    }
                    NumField("الكمية (${item?.unit ?: "قطعة"})", qty) { qty = it; done = false }
                    if (tab == 0) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = good, onClick = { good = true }, label = { Text("سليم، يرجع للعربية") })
                            FilterChip(selected = !good, onClick = { good = false }, label = { Text("تالف") })
                        }
                        val suggested = (item?.sellPrice ?: 0.0) * n
                        NumField("المبلغ المرتد للعميل", refund.ifBlank { if (suggested > 0) Fmt.money(suggested) else "" }) { refund = it }
                        PrimaryButton("تسجيل المرتجع", enabled = item != null && n > 0) {
                            onReturn(item!!.id, n, Fmt.num(refund.ifBlank { Fmt.money(suggested) }) ?: 0.0, good); reset()
                        }
                    } else {
                        Text("على العربية: $onTruck", color = c.muted, fontSize = 12.sp)
                        Row(Modifier.verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("انتهاء صلاحية", "عطل ثلاجة", "كسر", "أخرى").forEach { r ->
                                FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r, fontSize = 12.sp) })
                            }
                        }
                        PrimaryButton("تسجيل الهالك", enabled = item != null && n in 1..onTruck) {
                            onWaste(item!!.id, n, reason); reset()
                        }
                    }
                    if (done) Text("تم التسجيل", color = c.good, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    if (picking) {
        var s by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { picking = false }, title = { Text("اختار الصنف") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(s, { s = it }, label = { Text("بحث") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    source.filter { s.isBlank() || it.name.contains(s.trim(), ignoreCase = true) }.forEach { i ->
                        Text(i.name, color = c.ink, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable { item = i; picking = false; done = false }.padding(vertical = 10.dp))
                    }
                    if (source.isEmpty()) Text("مفيش أصناف.", color = c.muted, fontSize = 13.sp)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picking = false }) { Text("إغلاق") } },
        )
    }
}
