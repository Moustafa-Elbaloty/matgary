package com.matgary.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.matgary.app.ui.theme.AppTheme

/** Solid background with soft single-hue light behind the glass cards. */
@Composable
fun ScreenBackground(content: @Composable BoxScope.() -> Unit) {
    val c = AppTheme.colors
    Box(Modifier.fillMaxSize().background(c.bg)) {
        if (c.isGlass) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.width * 0.9f
                val top = Offset(size.width * 0.95f, 0f)
                val bottom = Offset(0f, size.height)
                drawCircle(Brush.radialGradient(listOf(c.blob.copy(alpha = 0.8f), Color.Transparent), top, r), r, top)
                drawCircle(Brush.radialGradient(listOf(c.blob.copy(alpha = 0.5f), Color.Transparent), bottom, r), r, bottom)
            }
        }
        Box(Modifier.fillMaxSize().systemBarsPadding(), content = content)
    }
}

/** Translucent card. In the classic theme it becomes a plain white card. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = AppTheme.colors
    Column(
        modifier.clip(shape).background(c.glass).border(1.dp, c.glassBorder, shape),
        content = content,
    )
}

/** App logo: one snowflake, a different material in each theme. */
@Composable
fun AppLogo(size: Dp, modifier: Modifier = Modifier) {
    val c = AppTheme.colors
    val shape = RoundedCornerShape(size * 0.3f)
    Box(
        modifier.size(size).clip(shape).background(c.logoBg).border(1.dp, c.logoBorder, shape),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.56f)) {
            val s = this.size.minDimension / 60f
            val m = Offset(this.size.width / 2f, this.size.height / 2f)
            val stroke = Stroke(width = 4f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
            for (angle in listOf(0f, 60f, 120f)) {
                rotate(angle, pivot = m) {
                    val arm = Path().apply {
                        moveTo(m.x, m.y - 24 * s); lineTo(m.x, m.y + 24 * s)
                        moveTo(m.x - 7 * s, m.y - 16 * s); lineTo(m.x, m.y - 10 * s); lineTo(m.x + 7 * s, m.y - 16 * s)
                        moveTo(m.x - 7 * s, m.y + 16 * s); lineTo(m.x, m.y + 10 * s); lineTo(m.x + 7 * s, m.y + 16 * s)
                    }
                    drawPath(arm, c.logoStroke, style = stroke)
                }
            }
            drawCircle(c.logoStroke, 4f * s, m)
        }
    }
}
