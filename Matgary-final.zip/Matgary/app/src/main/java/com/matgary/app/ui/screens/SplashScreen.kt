package com.matgary.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.ui.components.AppLogo
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val c = AppTheme.colors
    LaunchedEffect(Unit) { delay(1600); onDone() }
    ScreenBackground {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            AppLogo(140.dp)
            Spacer(Modifier.height(24.dp))
            Text("متجري", color = c.ink, fontSize = 36.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Text("مخزنك وعربيتك في جيبك", color = c.muted, fontSize = 14.sp)
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            GlassCard(Modifier.padding(bottom = 44.dp), RoundedCornerShape(20.dp)) {
                Text(
                    "تطوير: مصطفى البلوطي", color = c.ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                )
            }
        }
    }
}
