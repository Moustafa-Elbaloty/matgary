package com.matgary.app.data

import android.content.Context
import androidx.room.Room
import androidx.room.withTransaction
import com.matgary.app.data.db.AppDb
import com.matgary.app.data.db.Customer
import com.matgary.app.data.db.CustomerReturn
import com.matgary.app.data.db.Load
import com.matgary.app.data.db.LoadLine
import com.matgary.app.data.db.MIGRATION_1_2
import com.matgary.app.data.db.MIGRATION_2_3
import com.matgary.app.data.db.MIGRATION_3_4
import com.matgary.app.data.db.MIGRATION_4_5
import com.matgary.app.data.db.Closing
import com.matgary.app.data.db.Expense
import com.matgary.app.data.db.ItemSales
import com.matgary.app.data.db.Payment
import com.matgary.app.data.db.Sale
import com.matgary.app.data.db.SaleLine
import com.matgary.app.data.db.TruckBatch
import com.matgary.app.data.db.Waste
import com.matgary.app.data.db.Batch
import com.matgary.app.data.db.Item
import com.matgary.app.data.db.Movement
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.io.File
import java.security.SecureRandom
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ItemRow(val item: Item, val stock: Int, val nearestExpiry: Int?)

/** Totals for a period. Used by day closing now and by the weekly and monthly reports next. */
data class DaySummary(
    val salesCount: Int, val salesTotal: Double, val cashSales: Double, val walletSales: Double,
    val creditTotal: Double, val creditPaid: Double, val cogs: Double, val debtPayments: Double,
    val refunds: Double, val goodReturnCost: Double, val wasteCost: Double, val expenses: Double,
    val loadedQty: Int, val soldQty: Int, val goodReturnQty: Int, val truckQty: Int,
) {
    val revenue get() = salesTotal - refunds
    val grossProfit get() = revenue - (cogs - goodReturnCost)
    val netProfit get() = grossProfit - wasteCost - expenses
    /** Cash that should be in hand: cash sales + paid part of credit sales + debt payments - refunds - expenses. Wallet money is not cash. */
    val expectedCash get() = cashSales + creditPaid + debtPayments - refunds - expenses
}

data class ReportData(
    val from: Int, val to: Int, val current: DaySummary, val previous: DaySummary,
    val topSold: List<ItemSales>, val topProfit: List<ItemSales>,
)

data class StockValue(val cost: Double, val sell: Double)

data class DebtRow(val customer: Customer, val balance: Double, val oldestOpenDay: Int?)

data class LedgerEntry(val time: Long, val day: Int, val title: String, val amount: Double, val balanceAfter: Double)

data class SaleInput(val itemId: Long, val qty: Int, val unitPrice: Double)

data class TruckRow(val item: Item, val qty: Int, val nearestExpiry: Int?)

enum class Flag { OUT, LOW, EXPIRED, EXPIRING }

fun ItemRow.flags(warnDays: Int, today: Int): List<Flag> = buildList {
    if (stock == 0) add(Flag.OUT) else if (item.minQty > 0 && stock <= item.minQty) add(Flag.LOW)
    nearestExpiry?.let { if (it < today) add(Flag.EXPIRED) else if (it - today <= warnDays) add(Flag.EXPIRING) }
}

/** Opens the database encrypted with SQLCipher. The passphrase is random and kept sealed by the Keystore. */
private fun openDb(ctx: Context, secure: SecureStore): AppDb {
    System.loadLibrary("sqlcipher")
    val pass = secure.get("db_pass") ?: Crypto.b64(ByteArray(32).also { SecureRandom().nextBytes(it) })
        .also { secure.put("db_pass", it) }
    return Room.databaseBuilder(ctx, AppDb::class.java, "matgary.db")
        .openHelperFactory(SupportOpenHelperFactory(pass.toByteArray()))
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
        .build()
}

class InventoryRepo(ctx: Context, secure: SecureStore) {
    private val appCtx = ctx.applicationContext
    private val db = openDb(appCtx, secure)
    private val dao = db.dao()

    fun rows(): Flow<List<ItemRow>> = combine(dao.items(), dao.liveBatches()) { items, batches ->
        val byItem = batches.groupBy { it.itemId }
        items.map { i ->
            val b = byItem[i.id].orEmpty()
            ItemRow(i, b.sumOf { it.qty }, b.mapNotNull { it.expiryDay }.minOrNull())
        }
    }

    fun batches(itemId: Long) = dao.batchesOf(itemId)
    fun movements(itemId: Long) = dao.movementsOf(itemId)

    suspend fun save(item: Item): Long =
        if (item.id == 0L) dao.insertItem(item.copy(createdDay = Dates.today())) else { dao.updateItem(item); item.id }

    suspend fun delete(id: Long) = dao.deleteItem(id)

    suspend fun receive(itemId: Long, qty: Int, costPerUnit: Double, expiryDay: Int?) = db.withTransaction {
        val day = Dates.today()
        dao.insertBatch(Batch(itemId = itemId, qty = qty, initialQty = qty, costPerUnit = costPerUnit, expiryDay = expiryDay, receivedDay = day))
        dao.insertMovement(Movement(itemId = itemId, type = "IN", qty = qty, day = day))
    }

    /** Takes qty from the batches that expire first. Returns false (and changes nothing) if stock is not enough. Used by sales, waste and loading in the next steps. */
    suspend fun consume(itemId: Long, qty: Int, type: String, note: String = ""): Boolean = db.withTransaction {
        val batches = dao.fifoBatches(itemId)
        if (qty <= 0 || batches.sumOf { it.qty } < qty) return@withTransaction false
        var left = qty
        var cost = 0.0
        for (b in batches) {
            if (left == 0) break
            val take = minOf(left, b.qty)
            dao.setBatchQty(b.id, b.qty - take)
            cost += take * b.costPerUnit
            left -= take
        }
        val day = Dates.today()
        if (type == "WASTE") dao.insertWaste(Waste(day = day, itemId = itemId, name = dao.item(itemId)?.name ?: "", qty = qty, cost = cost, reason = note, source = "WAREHOUSE"))
        dao.insertMovement(Movement(itemId = itemId, type = type, qty = qty, day = day, note = note))
        true
    }

    // ---- Truck ----

    fun truckRows(): Flow<List<TruckRow>> = combine(dao.items(), dao.truckBatches()) { items, tb ->
        val byItem = tb.filter { it.qty > 0 }.groupBy { it.itemId }
        items.filter { byItem.containsKey(it.id) }.map { i ->
            val b = byItem.getValue(i.id)
            TruckRow(i, b.sumOf { it.qty }, b.mapNotNull { it.expiryDay }.minOrNull())
        }
    }

    fun lastLoadLines(): Flow<List<LoadLine>> = dao.lastLoadLines()

    /** Moves stock from the warehouse to the truck, earliest expiry first. Returns false and changes nothing if any item is short. */
    suspend fun loadTruck(lines: List<Pair<Long, Int>>): Boolean = db.withTransaction {
        val wanted = lines.groupBy({ it.first }, { it.second }).mapValues { it.value.sum() }.filterValues { it > 0 }
        if (wanted.isEmpty() || wanted.any { (id, q) -> dao.stockOf(id) < q }) return@withTransaction false
        val day = Dates.today()
        val loadId = dao.insertLoad(Load(day = day))
        for ((itemId, qty) in wanted) {
            var left = qty
            for (b in dao.fifoBatches(itemId)) {
                if (left == 0) break
                val take = minOf(left, b.qty)
                dao.setBatchQty(b.id, b.qty - take)
                dao.insertTruckBatch(TruckBatch(itemId = itemId, qty = take, costPerUnit = b.costPerUnit, expiryDay = b.expiryDay, loadId = loadId))
                left -= take
            }
            dao.insertLoadLine(LoadLine(loadId = loadId, itemId = itemId, qty = qty))
            dao.insertMovement(Movement(itemId = itemId, type = "LOAD", qty = qty, day = day))
        }
        true
    }

    /** Puts everything on the truck back into the warehouse with its original expiry and cost. */
    suspend fun returnAllToWarehouse() = db.withTransaction {
        val day = Dates.today()
        for (t in dao.allTruckBatches()) {
            if (t.qty > 0) {
                dao.insertBatch(Batch(itemId = t.itemId, qty = t.qty, initialQty = t.qty, costPerUnit = t.costPerUnit, expiryDay = t.expiryDay, receivedDay = day))
                dao.insertMovement(Movement(itemId = t.itemId, type = "UNLOAD", qty = t.qty, day = day))
            }
        }
        dao.clearTruck()
    }

    // ---- Sales, returns, waste ----

    fun customers() = dao.customers()
    fun salesToday() = dao.salesTotal(Dates.today())
    suspend fun addCustomer(name: String, phone: String): Long = dao.insertCustomer(Customer(name = name.trim(), phone = phone.trim()))

    /** Sells from the truck, earliest expiry first. Returns the sale id, or null (nothing changed) if the truck is short. */
    suspend fun sell(lines: List<SaleInput>, customerId: Long?, payment: String, discount: Double, paidNow: Double): Long? = db.withTransaction {
        val merged = lines.groupBy { it.itemId }
            .map { (id, l) -> Triple(id, l.sumOf { it.qty }, l.first().unitPrice) }
            .filter { it.second > 0 }
        if (merged.isEmpty() || merged.any { (id, q, _) -> dao.truckStockOf(id) < q }) return@withTransaction null
        val day = Dates.today()
        var gross = 0.0
        var cost = 0.0
        val costs = HashMap<Long, Double>()
        for ((id, qty, price) in merged) {
            var left = qty
            var c = 0.0
            for (b in dao.truckFifo(id)) {
                if (left == 0) break
                val take = minOf(left, b.qty)
                dao.setTruckQty(b.id, b.qty - take)
                c += take * b.costPerUnit
                left -= take
            }
            costs[id] = c
            cost += c
            gross += qty * price
        }
        val total = (gross - discount).coerceAtLeast(0.0)
        val paid = if (payment == "CREDIT") paidNow.coerceIn(0.0, total) else total
        val saleId = dao.insertSale(Sale(day = day, time = System.currentTimeMillis(), customerId = customerId, payment = payment, discount = discount, total = total, paid = paid, cost = cost))
        for ((id, qty, price) in merged) {
            dao.insertSaleLine(SaleLine(saleId = saleId, itemId = id, name = dao.item(id)?.name ?: "", qty = qty, unitPrice = price, unitCost = costs.getValue(id) / qty))
            dao.insertMovement(Movement(itemId = id, type = "OUT", qty = qty, day = day))
        }
        saleId
    }

    /** Customer returned goods. Good ones go back on the truck, damaged ones are recorded as a loss. */
    suspend fun customerReturn(itemId: Long, qty: Int, refund: Double, good: Boolean) = db.withTransaction {
        val item = dao.item(itemId) ?: return@withTransaction
        val day = Dates.today()
        dao.insertReturn(CustomerReturn(day = day, itemId = itemId, name = item.name, qty = qty, refund = refund, good = good))
        if (good) dao.insertTruckBatch(TruckBatch(itemId = itemId, qty = qty, costPerUnit = item.buyPrice, expiryDay = null, loadId = 0))
        else dao.insertWaste(Waste(day = day, itemId = itemId, name = item.name, qty = qty, cost = item.buyPrice * qty, reason = "مرتجع تالف", source = "RETURN"))
        dao.insertMovement(Movement(itemId = itemId, type = "RETURN", qty = qty, day = day, note = if (good) "سليم" else "تالف"))
    }

    suspend fun wasteFromTruck(itemId: Long, qty: Int, reason: String): Boolean = db.withTransaction {
        if (qty <= 0 || dao.truckStockOf(itemId) < qty) return@withTransaction false
        var left = qty
        var cost = 0.0
        for (b in dao.truckFifo(itemId)) {
            if (left == 0) break
            val take = minOf(left, b.qty)
            dao.setTruckQty(b.id, b.qty - take)
            cost += take * b.costPerUnit
            left -= take
        }
        val day = Dates.today()
        dao.insertWaste(Waste(day = day, itemId = itemId, name = dao.item(itemId)?.name ?: "", qty = qty, cost = cost, reason = reason, source = "TRUCK"))
        dao.insertMovement(Movement(itemId = itemId, type = "WASTE", qty = qty, day = day, note = reason))
        true
    }

    // ---- Debts ----
    // A customer's balance = unpaid part of their credit sales minus what they paid later.
    // Payments are applied to the oldest invoices first, which gives the age of the oldest open debt.

    fun debts(): Flow<List<DebtRow>> = combine(dao.customers(), dao.customerSales(), dao.payments()) { customers, sales, pays ->
        customers.mapNotNull { cu ->
            val mine = sales.filter { it.customerId == cu.id }.sortedBy { it.time }
            var remaining = pays.filter { it.customerId == cu.id }.sumOf { it.amount }
            var balance = -remaining
            var oldest: Int? = null
            for (s in mine) {
                val owed = s.total - s.paid
                if (owed <= 0.005) continue
                balance += owed
                if (oldest == null) {
                    if (remaining >= owed - 0.005) remaining -= owed else oldest = s.day
                }
            }
            if (balance > 0.005) DebtRow(cu, balance, oldest) else null
        }.sortedByDescending { it.balance }
    }

    fun totalDebt(): Flow<Double> = debts().map { rows -> rows.sumOf { it.balance } }

    /** Newest first, each line with the balance after it. */
    fun ledger(customerId: Long): Flow<List<LedgerEntry>> = combine(dao.customerSales(), dao.payments()) { sales, pays ->
        val raw = buildList {
            sales.filter { it.customerId == customerId && it.total - it.paid > 0.005 }.forEach {
                val title = "فاتورة أجل ${Fmt.money(it.total)}" + if (it.paid > 0) " (دُفع ${Fmt.money(it.paid)})" else ""
                add(LedgerEntry(it.time, it.day, title, it.total - it.paid, 0.0))
            }
            pays.filter { it.customerId == customerId }.forEach { add(LedgerEntry(it.time, it.day, "دفعة", -it.amount, 0.0)) }
        }.sortedBy { it.time }
        var run = 0.0
        raw.map { run += it.amount; it.copy(balanceAfter = run) }.reversed()
    }

    suspend fun addPayment(customerId: Long, amount: Double) {
        if (amount > 0) dao.insertPayment(Payment(customerId = customerId, day = Dates.today(), time = System.currentTimeMillis(), amount = amount))
    }

    suspend fun updateCustomer(c: Customer) = dao.updateCustomer(c)

    // ---- Expenses, closing, reports ----

    fun expenses() = dao.expenses()
    fun closingFor(day: Int) = dao.closingFor(day)

    suspend fun addExpense(category: String, amount: Double, note: String) {
        if (amount > 0) dao.insertExpense(Expense(day = Dates.today(), time = System.currentTimeMillis(), category = category, amount = amount, note = note.trim()))
    }

    suspend fun deleteExpense(id: Long) = dao.deleteExpense(id)

    suspend fun saveClosing(day: Int, expected: Double, actual: Double, note: String) =
        dao.insertClosing(Closing(day = day, time = System.currentTimeMillis(), expectedCash = expected, actualCash = actual, note = note.trim()))

    suspend fun summary(from: Int, to: Int): DaySummary = DaySummary(
        salesCount = dao.salesCount(from, to), salesTotal = dao.salesTotalRange(from, to),
        cashSales = dao.salesTotalBy(from, to, "CASH"), walletSales = dao.salesTotalBy(from, to, "WALLET"),
        creditTotal = dao.salesTotalBy(from, to, "CREDIT"), creditPaid = dao.creditPaid(from, to),
        cogs = dao.cogs(from, to), debtPayments = dao.debtPayments(from, to),
        refunds = dao.refunds(from, to), goodReturnCost = dao.goodReturnCost(from, to),
        wasteCost = dao.wasteCost(from, to), expenses = dao.expenseTotal(from, to),
        loadedQty = dao.loadedQty(from, to), soldQty = dao.soldQty(from, to),
        goodReturnQty = dao.goodReturnQty(from, to), truckQty = dao.truckQty(),
    )

    /** Physical count of the truck. Shortages become a loss, surplus is added back to the truck. */
    suspend fun applyTruckCount(actual: Map<Long, Int>) = db.withTransaction {
        val day = Dates.today()
        for ((id, want) in actual) {
            val have = dao.truckStockOf(id)
            if (want < have) {
                var left = have - want
                var cost = 0.0
                for (b in dao.truckFifo(id)) {
                    if (left == 0) break
                    val take = minOf(left, b.qty)
                    dao.setTruckQty(b.id, b.qty - take)
                    cost += take * b.costPerUnit
                    left -= take
                }
                dao.insertWaste(Waste(day = day, itemId = id, name = dao.item(id)?.name ?: "", qty = have - want, cost = cost, reason = "عجز جرد", source = "TRUCK"))
                dao.insertMovement(Movement(itemId = id, type = "ADJUST", qty = have - want, day = day, note = "عجز"))
            } else if (want > have) {
                val item = dao.item(id) ?: continue
                dao.insertTruckBatch(TruckBatch(itemId = id, qty = want - have, costPerUnit = item.buyPrice, expiryDay = null, loadId = 0))
                dao.insertMovement(Movement(itemId = id, type = "ADJUST", qty = want - have, day = day, note = "زيادة"))
            }
        }
    }

    // ---- Reports ----

    /** The last `days` days (ending today) against the same number of days before them. */
    suspend fun report(days: Int): ReportData {
        val to = Dates.today()
        val from = to - (days - 1)
        val sales = dao.itemSales(from, to)
        return ReportData(
            from, to, summary(from, to), summary(from - days, from - 1),
            sales.sortedByDescending { it.qty }.take(5), sales.sortedByDescending { it.profit }.take(5),
        )
    }

    suspend fun stockValue() = StockValue(dao.warehouseCost() + dao.truckCost(), dao.warehouseSell() + dao.truckSell())

    /** Items that existed for 30+ days and had no sale since the cutoff. The caller keeps only those still in stock. */
    suspend fun stagnantItems(cutoff: Int) = dao.stagnantCandidates(cutoff)

    // ---- Backup support ----

    /** Writes everything still in the WAL journal into the main database file, so the file can be copied safely. */
    suspend fun checkpoint() = withContext(Dispatchers.IO) {
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").use { it.moveToFirst() }
    }

    fun dbFile(): File = appCtx.getDatabasePath("matgary.db")

    fun close() = db.close()
}
