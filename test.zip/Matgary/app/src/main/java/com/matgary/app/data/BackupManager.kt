package com.matgary.app.data

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Backup file = header + salt + iv + AES-GCM(data).
 * The key comes from a backup password the trader chooses, so the file can be opened on a new phone.
 * Inside: the database file (already SQLCipher-encrypted), its passphrase, the store name and the theme.
 * If the backup password is forgotten, the backup cannot be opened by anyone, including us.
 */
object BackupManager {
    private val MAGIC = "MTJB1".toByteArray()
    const val DB_VERSION = 7
    private const val ITERATIONS = 210_000

    class Restored(val passphrase: String, val storeName: String, val theme: String, val db: ByteArray)

    private fun key(password: String, salt: ByteArray) = SecretKeySpec(
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)).encoded,
        "AES",
    )

    private fun random(n: Int) = ByteArray(n).also { SecureRandom().nextBytes(it) }

    fun create(secure: SecureStore, dbFile: File, password: String, storeName: String, theme: String): ByteArray {
        val pass = secure.get("db_pass") ?: error("لا توجد بيانات للنسخ")
        val db = dbFile.readBytes()
        val plain = ByteArrayOutputStream().also {
            DataOutputStream(it).run { writeUTF(pass); writeUTF(storeName); writeUTF(theme); writeInt(db.size); write(db); flush() }
        }.toByteArray()
        val header = MAGIC + ByteBuffer.allocate(4).putInt(DB_VERSION).array()
        val salt = random(16)
        val iv = random(12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.ENCRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
            updateAAD(header + salt)
        }
        return header + salt + iv + cipher.doFinal(plain)
    }

    /** Throws IllegalStateException for a newer backup, and another exception for a wrong password or a damaged file. */
    fun open(data: ByteArray, password: String): Restored {
        val hLen = MAGIC.size + 4
        require(data.size > hLen + 16 + 12 + 16 && data.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) { "not a backup" }
        val version = ByteBuffer.wrap(data, MAGIC.size, 4).int
        if (version > DB_VERSION) throw IllegalStateException("newer")
        val salt = data.copyOfRange(hLen, hLen + 16)
        val iv = data.copyOfRange(hLen + 16, hLen + 28)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply {
            init(Cipher.DECRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv))
            updateAAD(data.copyOfRange(0, hLen) + salt)
        }
        val plain = cipher.doFinal(data, hLen + 28, data.size - hLen - 28)
        DataInputStream(plain.inputStream()).run {
            val pass = readUTF()
            val store = readUTF()
            val theme = readUTF()
            val db = ByteArray(readInt()).also { readFully(it) }
            return Restored(pass, store, theme, db)
        }
    }

    /** Replaces the database file. The app must be restarted right after. */
    fun writeDatabase(ctx: Context, r: Restored) {
        val f = ctx.getDatabasePath("matgary.db")
        f.parentFile?.mkdirs()
        File(f.path + "-wal").delete()
        File(f.path + "-shm").delete()
        f.writeBytes(r.db)
    }
}
