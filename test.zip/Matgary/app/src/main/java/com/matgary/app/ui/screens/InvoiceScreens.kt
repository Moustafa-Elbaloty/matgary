package com.matgary.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Dates
import com.matgary.app.data.Fmt
import com.matgary.app.data.ReceiptPdf
import com.matgary.app.data.db.AuditEntry
import com.matgary.app.data.db.Customer
import com.matgary.app.data.db.Sale
import com.matgary.app.data.db.SaleLine
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun hhmm(t: Long) = SimpleDateFormat("HH:mm", Locale.US).format(Date(t))

@Composable
fun InvoicesScreen(sales: List<Sale>, customers: List<Customer>, onOpen: (Long) -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    // newest first, with a date heading whenever the day changes
    val rows = buildList<Any> {
        var last = Int.MIN_VALUE
        sales.forEach { if (it.day != last) { add(it.day); last = it.day }; add(it) }
    }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("الفواتير", onBack)
            if (sales.isEmpty()) {
                Text("لسه مفيش فواتير.", color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 24.dp))
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(rows) { r ->
                        if (r is Int) {
                            Text(if (r == today) "النهاردة · ${Dates.fmt(r)}" else Dates.fmt(r), color = c.muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                        } else if (r is Sale) {
                            val name = customers.firstOrNull { it.id == r.customerId }?.name
                            GlassCard(Modifier.fillMaxWidth().clickable { onOpen(r.id) }) {
                                Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("فاتورة #${r.id} · ${hhmm(r.time)}", color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                        Text((name ?: "بدون عميل") + " · " + ReceiptPdf.payLabel(r.payment), color = c.muted, fontSize = 12.sp)
                                    }
                                    Text(Fmt.money(r.total), color = c.ink, fontSize = 19.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InvoiceDetailScreen(
    sale: Sale, lines: List<SaleLine>, customer: String?,
    onVoid: (String) -> Unit, onReceipt: () -> Unit, onPrint: () -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    var voiding by remember { mutableStateOf(false) }
    var reason by remember { mutableStateOf("") }
    val gross = lines.sumOf { it.qty * it.unitPrice }
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("فاتورة #${sale.id}", onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${Dates.fmt(sale.day)} · ${hhmm(sale.time)}", color = c.muted, fontSize = 13.sp)
                    Text((customer ?: "بدون عميل") + " · " + ReceiptPdf.payLabel(sale.payment), color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            GlassCard(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    lines.forEach { l ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(l.name, color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text("${l.qty} × ${Fmt.money(l.unitPrice)}", color = c.muted, fontSize = 12.sp)
                            }
                            Text(Fmt.money(l.qty * l.unitPrice), color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            GlassCard(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("المجموع", color = c.muted, fontSize = 14.sp); Text(Fmt.money(gross), color = c.ink, fontSize = 14.sp) }
                    if (sale.discount > 0) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("الخصم", color = c.muted, fontSize = 14.sp); Text("- ${Fmt.money(sale.discount)}", color = c.warn, fontSize = 14.sp) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("الإجمالي", color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Black); Text(Fmt.money(sale.total), color = c.ink, fontSize = 18.sp, fontWeight = FontWeight.Black) }
                    if (sale.payment == "CREDIT") Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("مدفوع ${Fmt.money(sale.paid)}", color = c.muted, fontSize = 13.sp)
                        Text("متبقي ${Fmt.money(sale.total - sale.paid)}", color = c.warn, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            PrimaryButton("مشاركة إيصال PDF", Modifier.padding(top = 12.dp), onClick = onReceipt)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPrint, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("طباعة", color = c.accent, fontWeight = FontWeight.Bold) }
                OutlinedButton(onClick = { voiding = true }, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) { Text("إلغاء الفاتورة", color = c.danger, fontWeight = FontWeight.Bold) }
            }
        }
    }
    if (voiding) AlertDialog(
        onDismissRequest = { voiding = false }, title = { Text("إلغاء الفاتورة #${sale.id}؟") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("البضاعة هترجع للعربية (من غير تاريخ صلاحية)، والفاتورة هتتشال من المبيعات والتقارير، وهيتسجل ده في سجل التعديلات.", fontSize = 13.sp)
                OutlinedTextField(reason, { reason = it }, label = { Text("السبب (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { TextButton(onClick = { voiding = false; onVoid(reason.trim()) }) { Text("إلغاء الفاتورة", color = c.danger) } },
        dismissButton = { TextButton(onClick = { voiding = false }) { Text("رجوع") } },
    )
}

@Composable
fun AuditScreen(entries: List<AuditEntry>, onBack: () -> Unit) {
    val c = AppTheme.colors
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("سجل التعديلات", onBack)
            Text("كل إلغاء أو حذف أو تسوية بتتسجل هنا ومش بتتمسح.", color = c.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            if (entries.isEmpty()) {
                Text("لسه مفيش تعديلات.", color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 16.dp))
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(entries, key = { it.id }) { e ->
                        GlassCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(e.action, color = c.danger, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                    Text("${Dates.fmt(e.day)} · ${hhmm(e.time)}", color = c.muted, fontSize = 12.sp)
                                }
                                Text(e.detail, color = c.ink, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
