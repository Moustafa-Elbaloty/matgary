package com.matgary.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.DaySummary
import com.matgary.app.data.Fmt
import com.matgary.app.ui.components.AppLogo
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

enum class HomeDest { SALE, TRUCK, INVENTORY, DEBTS, RETURNS, EXPENSES, CLOSE, REPORTS, SETTINGS, BACKUP, INVOICES, AUDIT }

private val MENU = listOf(
    "بيع جديد" to HomeDest.SALE, "العربية" to HomeDest.TRUCK,
    "المخزن" to HomeDest.INVENTORY, "المديونيات" to HomeDest.DEBTS,
    "مرتجع وهالك" to HomeDest.RETURNS, "المصاريف" to HomeDest.EXPENSES,
    "تقفيل اليوم" to HomeDest.CLOSE, "التقارير" to HomeDest.REPORTS,
    "الفواتير" to HomeDest.INVOICES, "سجل التعديلات" to HomeDest.AUDIT,
)

@Composable
fun HomeScreen(
    storeName: String, licenseText: String, today: DaySummary?,
    stockAlerts: Int, expiryAlerts: Int, debtors: Int, backupDue: Boolean, onNav: (HomeDest) -> Unit,
) {
    val c = AppTheme.colors
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo(48.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(storeName, color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(licenseText, color = c.muted, fontSize = 12.sp)
                }
                TextButton(onClick = { onNav(HomeDest.SETTINGS) }) { Text("الإعدادات", color = c.accent) }
            }
            Spacer(Modifier.height(16.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("النهاردة", color = c.muted, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("المبيعات", today?.let { Fmt.money(it.salesTotal) } ?: "—", c.ink)
                        Stat("المصاريف", today?.let { Fmt.money(it.expenses) } ?: "—", c.ink)
                        Stat("صافي الربح", today?.let { Fmt.money(it.netProfit) } ?: "—", if ((today?.netProfit ?: 0.0) >= 0) c.good else c.danger)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            if (stockAlerts + expiryAlerts + debtors == 0) {
                Text("مفيش تنبيهات دلوقتي.", color = c.muted, fontSize = 13.sp)
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (stockAlerts > 0) Chip("$stockAlerts خلصت أو ناقصة", c.danger, Modifier.weight(1f)) { onNav(HomeDest.INVENTORY) }
                    if (expiryAlerts > 0) Chip("$expiryAlerts قربت صلاحيتها", c.warn, Modifier.weight(1f)) { onNav(HomeDest.INVENTORY) }
                    if (debtors > 0) Chip("$debtors عليهم فلوس", c.info, Modifier.weight(1f)) { onNav(HomeDest.DEBTS) }
                }
            }
            if (backupDue) {
                Spacer(Modifier.height(12.dp))
                GlassCard(Modifier.fillMaxWidth().clickable { onNav(HomeDest.BACKUP) }) {
                    Text("مفيش نسخة احتياطية حديثة. اضغط واعمل نسخة", color = c.warn, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(14.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            MENU.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { (label, dest) ->
                        GlassCard(Modifier.weight(1f).height(84.dp).clickable { onNav(dest) }) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(label, color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, color: Color) {
    val c = AppTheme.colors
    Column {
        Text(label, color = c.muted, fontSize = 12.sp)
        Text(value, color = color, fontSize = 20.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun Chip(text: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier.clickable(onClick = onClick)) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 14.dp))
    }
}
