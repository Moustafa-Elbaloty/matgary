package com.matgary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Dates
import com.matgary.app.data.Flag
import com.matgary.app.data.Fmt
import com.matgary.app.data.ItemRow
import com.matgary.app.data.db.Batch
import com.matgary.app.data.db.Item
import com.matgary.app.data.db.Movement
import com.matgary.app.data.flags
import com.matgary.app.ui.components.BarcodeScannerDialog
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

@Composable
internal fun Tag(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

internal fun qtyText(stock: Int, item: Item) =
    if (item.packSize > 1) "${stock / item.packSize} كرتونة و ${stock % item.packSize} ${item.unit}" else "$stock ${item.unit}"

@Composable
internal fun TopBar(title: String, onBack: () -> Unit) {
    val c = AppTheme.colors
    Row(Modifier.padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(
            onClick = onBack, modifier = Modifier.height(44.dp), shape = RoundedCornerShape(22.dp),
            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
            contentPadding = PaddingValues(horizontal = 16.dp),
        ) { Text("→ رجوع", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Text(title, color = c.ink, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
internal fun NumField(label: String, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value, onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
    )
}

@Composable
fun InventoryScreen(rows: List<ItemRow>, onAdd: () -> Unit, onOpen: (Long) -> Unit, onBack: () -> Unit) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    var q by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    val shown = rows.filter { r ->
        val f = r.flags(Dates.WARN_DAYS, today)
        val match = q.isBlank() || r.item.name.contains(q.trim(), ignoreCase = true) || r.item.barcode.contains(q.trim())
        match && when (filter) {
            1 -> f.any { it == Flag.OUT || it == Flag.LOW }
            2 -> f.any { it == Flag.EXPIRED || it == Flag.EXPIRING }
            else -> true
        }
    }
    ScreenBackground {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            TopBar("المخزن", onBack)
            var scanning by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    q, { q = it }, label = { Text("ابحث بالاسم أو الباركود") }, singleLine = true,
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = fieldColors(),
                )
                TextButton(onClick = { scanning = true }) { Text("مسح", color = c.accent, fontWeight = FontWeight.Bold) }
            }
            if (scanning) BarcodeScannerDialog(onResult = { q = it }, onDismiss = { scanning = false })
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("الكل", "ناقص أو خلص", "قرب الصلاحية").forEachIndexed { i, label ->
                    FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(label) })
                }
            }
            if (shown.isEmpty()) {
                Text(
                    if (rows.isEmpty()) "لسه مفيش أصناف. اضغط \"إضافة صنف\" وابدأ." else "مفيش أصناف مطابقة.",
                    color = c.muted, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(top = 24.dp),
                )
            } else {
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shown, key = { it.item.id }) { r ->
                        GlassCard(Modifier.fillMaxWidth().clickable { onOpen(r.item.id) }) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(r.item.name, color = c.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Text("الرصيد: ${qtyText(r.stock, r.item)}", color = c.muted, fontSize = 13.sp)
                                val flags = r.flags(Dates.WARN_DAYS, today)
                                if (flags.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    flags.forEach { f ->
                                        when (f) {
                                            Flag.OUT -> Tag("خلص", c.danger)
                                            Flag.LOW -> Tag("قارب على النفاد", c.warn)
                                            Flag.EXPIRED -> Tag("منتهي الصلاحية", c.danger)
                                            Flag.EXPIRING -> Tag("باقي ${r.nearestExpiry!! - today} يوم", c.warn)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            PrimaryButton("إضافة صنف", Modifier.padding(vertical = 12.dp), onClick = onAdd)
        }
    }
}

@Composable
fun ItemFormScreen(initial: Item?, onSave: (Item) -> Unit, onCancel: () -> Unit) {
    val c = AppTheme.colors
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var barcode by remember { mutableStateOf(initial?.barcode ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var unit by remember { mutableStateOf(initial?.unit ?: "قطعة") }
    var pack by remember { mutableStateOf(initial?.packSize?.toString() ?: "1") }
    var buy by remember { mutableStateOf(initial?.let { Fmt.money(it.buyPrice) } ?: "") }
    var sell by remember { mutableStateOf(initial?.let { Fmt.money(it.sellPrice) } ?: "") }
    var min by remember { mutableStateOf(initial?.minQty?.toString() ?: "0") }
    val b = Fmt.num(buy) ?: 0.0
    val s = Fmt.num(sell) ?: 0.0
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar(if (initial == null) "صنف جديد" else "تعديل الصنف", onCancel)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("اسم الصنف") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                    OutlinedTextField(category, { category = it }, label = { Text("التصنيف (مثلاً: مجمدات، حلويات)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                    var scanning by remember { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(barcode, { barcode = it }, label = { Text("الباركود (اختياري)") }, singleLine = true,
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                        TextButton(onClick = { scanning = true }) { Text("مسح", color = c.accent, fontWeight = FontWeight.Bold) }
                    }
                    if (scanning) BarcodeScannerDialog(onResult = { barcode = it }, onDismiss = { scanning = false })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(unit, { unit = it }, label = { Text("الوحدة") }, singleLine = true,
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = fieldColors())
                        NumField("قطع في الكرتونة", pack, Modifier.weight(1f)) { pack = it }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NumField("سعر الشراء", buy, Modifier.weight(1f)) { buy = it }
                        NumField("سعر البيع", sell, Modifier.weight(1f)) { sell = it }
                    }
                    if (b > 0 && s > 0) {
                        val pct = (s - b) / b * 100
                        Text("هامش الربح: ${"%.1f".format(pct)}%  (${Fmt.money(s - b)} للوحدة)",
                            color = if (pct >= 0) c.good else c.danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    NumField("حد التنبيه (أقل كمية)", min) { min = it }
                }
            }
            Spacer(Modifier.height(16.dp))
            PrimaryButton("حفظ", enabled = name.isNotBlank()) {
                onSave(
                    (initial ?: Item(name = "")).copy(
                        name = name.trim(), barcode = barcode.trim(), category = category.trim(),
                        unit = unit.ifBlank { "قطعة" }.trim(),
                        packSize = (Fmt.num(pack)?.toInt() ?: 1).coerceAtLeast(1),
                        buyPrice = b, sellPrice = s, minQty = (Fmt.num(min)?.toInt() ?: 0).coerceAtLeast(0),
                    )
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun ItemDetailScreen(
    item: Item, stock: Int, batches: List<Batch>, moves: List<Movement>,
    onReceive: (units: Int, cost: Double, expiry: Int?) -> Unit,
    onWaste: (units: Int, reason: String) -> Unit,
    onEdit: () -> Unit, onDelete: () -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    val today = remember { Dates.today() }
    var dialog by remember { mutableIntStateOf(0) } // 1 receive, 2 waste, 3 delete
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar(item.name, onBack)
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الرصيد الحالي", color = c.muted, fontSize = 13.sp)
                    Text(qtyText(stock, item), color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("شراء ${Fmt.money(item.buyPrice)} · بيع ${Fmt.money(item.sellPrice)} للوحدة", color = c.muted, fontSize = 13.sp)
                    if (item.buyPrice > 0 && item.sellPrice > 0) {
                        val pct = (item.sellPrice - item.buyPrice) / item.buyPrice * 100
                        Text("هامش الربح ${"%.1f".format(pct)}%", color = if (pct >= 0) c.good else c.danger, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("استلام بضاعة", Modifier.weight(1f)) { dialog = 1 }
                OutlinedButton(onClick = { dialog = 2 }, enabled = stock > 0, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) {
                    Text("هالك / تالف", color = c.danger, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("الدفعات (الأقدم صلاحية الأول)", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (batches.isEmpty()) Text("مفيش دفعات. استلم بضاعة عشان تبدأ.", color = c.muted, fontSize = 13.sp)
            batches.forEach { b ->
                GlassCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("المتبقي ${b.qty} من ${b.initialQty}", color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("استلام ${Dates.fmt(b.receivedDay)} · تكلفة ${Fmt.money(b.costPerUnit)}", color = c.muted, fontSize = 12.sp)
                        }
                        val e = b.expiryDay
                        when {
                            e == null -> Tag("بدون صلاحية", c.muted)
                            e < today -> Tag("منتهي", c.danger)
                            e - today <= Dates.WARN_DAYS -> Tag("باقي ${e - today} يوم", c.warn)
                            else -> Tag(Dates.fmt(e), c.good)
                        }
                    }
                }
            }
            if (moves.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("آخر الحركات", color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                moves.take(10).forEach { m ->
                    val label = when (m.type) { "IN" -> "استلام"; "OUT" -> "بيع"; "WASTE" -> "هالك"; "LOAD" -> "تحميل للعربية"; "UNLOAD" -> "رجوع من العربية"; "VOID" -> "إلغاء فاتورة"; "RETURN" -> "مرتجع"; else -> "تسوية" }
                    Text("${Dates.fmt(m.day)} · $label ${m.qty}${if (m.note.isNotBlank()) " · ${m.note}" else ""}", color = c.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Row(Modifier.padding(vertical = 12.dp)) {
                TextButton(onClick = onEdit) { Text("تعديل الصنف", color = c.accent) }
                TextButton(onClick = { dialog = 3 }) { Text("حذف الصنف", color = c.danger) }
            }
        }
    }
    when (dialog) {
        1 -> ReceiveDialog(item, { dialog = 0 }) { u, cost, e -> onReceive(u, cost, e); dialog = 0 }
        2 -> WasteDialog(item, stock, { dialog = 0 }) { u, r -> onWaste(u, r); dialog = 0 }
        3 -> AlertDialog(
            onDismissRequest = { dialog = 0 }, title = { Text("حذف ${item.name}؟") },
            text = { Text("هيتمسح الصنف وكل دفعاته وحركاته، ومش هتقدر ترجعه.") },
            confirmButton = { TextButton(onClick = { dialog = 0; onDelete() }) { Text("حذف", color = c.danger) } },
            dismissButton = { TextButton(onClick = { dialog = 0 }) { Text("إلغاء") } },
        )
    }
}

@Composable
private fun ReceiveDialog(item: Item, onDismiss: () -> Unit, onConfirm: (Int, Double, Int?) -> Unit) {
    var qty by remember { mutableStateOf("") }
    var carton by remember { mutableStateOf(false) }
    var cost by remember { mutableStateOf(Fmt.money(item.buyPrice)) }
    var expiry by remember { mutableStateOf<Int?>(null) }
    var picking by remember { mutableStateOf(false) }
    val n = Fmt.num(qty)?.toInt() ?: 0
    val units = if (carton) n * item.packSize else n
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("استلام بضاعة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("الكمية", qty) { qty = it }
                if (item.packSize > 1) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !carton, onClick = { carton = false }, label = { Text(item.unit) })
                    FilterChip(selected = carton, onClick = { carton = true }, label = { Text("كرتونة") })
                }
                if (carton && n > 0) Text("= $units ${item.unit}", fontSize = 12.sp)
                NumField("سعر شراء ${item.unit}", cost) { cost = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { picking = true }) { Text(expiry?.let { "الصلاحية: ${Dates.fmt(it)}" } ?: "اختار تاريخ الصلاحية") }
                    if (expiry != null) TextButton(onClick = { expiry = null }) { Text("مسح") }
                }
            }
        },
        confirmButton = { TextButton(enabled = units > 0, onClick = { onConfirm(units, Fmt.num(cost) ?: 0.0, expiry) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
    if (picking) DatePickerBox(onPick = { expiry = it }, onDismiss = { picking = false })
}

@Composable
private fun WasteDialog(item: Item, stock: Int, onDismiss: () -> Unit, onConfirm: (Int, String) -> Unit) {
    var qty by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("انتهاء صلاحية") }
    val n = Fmt.num(qty)?.toInt() ?: 0
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("تسجيل هالك") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("الكمية (${item.unit})", qty) { qty = it }
                Text("المتاح $stock", fontSize = 12.sp)
                Row(Modifier.verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("انتهاء صلاحية", "عطل ثلاجة", "كسر", "أخرى").forEach { r ->
                        FilterChip(selected = reason == r, onClick = { reason = r }, label = { Text(r, fontSize = 12.sp) })
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = n in 1..stock, onClick = { onConfirm(n, reason) }) { Text("تسجيل") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DatePickerBox(onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val st = rememberDatePickerState()
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { st.selectedDateMillis?.let { onPick((it / 86_400_000L).toInt()) }; onDismiss() }) { Text("تم") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } },
    ) { DatePicker(state = st) }
}
