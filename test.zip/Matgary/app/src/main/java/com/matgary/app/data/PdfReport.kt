package com.matgary.app.data

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import com.matgary.app.data.db.Item
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.math.abs

/** Draws the report as a clean A4 PDF: colored header, key numbers, comparison table, bars, stock value. */
object PdfReport {
    private const val W = 595
    private const val H = 842
    private const val M = 36f
    internal const val BRAND = 0xFF0B6E8A.toInt()
    internal const val INK = 0xFF0F2A3D.toInt()
    internal const val MUTED = 0xFF5B7384.toInt()
    internal const val CARD = 0xFFF1F6F9.toInt()
    internal const val ZEBRA = 0xFFF7FAFC.toInt()
    internal const val GOOD = 0xFF15803D.toInt()
    internal const val BAD = 0xFFB91C1C.toInt()
    internal const val WARN = 0xFFB45309.toInt()

    internal fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }

    internal fun text(color: Int, size: Float, bold: Boolean = false, align: Paint.Align = Paint.Align.RIGHT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = size; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    /** Shrinks the text until it fits the given width. */
    internal fun fitted(p: Paint, s: String, maxW: Float): Paint {
        while (p.measureText(s) > maxW && p.textSize > 8f) p.textSize -= 1f
        return p
    }

    internal fun snowflake(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = r / 6f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; this.color = color
        }
        val s = r / 24f
        for (a in listOf(0f, 60f, 120f)) {
            c.save(); c.rotate(a, cx, cy)
            c.drawPath(Path().apply {
                moveTo(cx, cy - 24 * s); lineTo(cx, cy + 24 * s)
                moveTo(cx - 7 * s, cy - 16 * s); lineTo(cx, cy - 10 * s); lineTo(cx + 7 * s, cy - 16 * s)
                moveTo(cx - 7 * s, cy + 16 * s); lineTo(cx, cy + 10 * s); lineTo(cx + 7 * s, cy + 16 * s)
            }, p)
            c.restore()
        }
    }

    private class Pages(val store: String) {
        val doc = PdfDocument()
        private var no = 0
        private lateinit var page: PdfDocument.Page
        var y = M
        val c: Canvas get() = page.canvas

        private fun footer() {
            c.drawRect(M, H - 42f, W - M, H - 41f, fill(0xFFE2EAEF.toInt()))
            c.drawText("$store · تطوير مصطفى البلوطي", W - M, H - 24f, text(MUTED, 10f))
            c.drawText("صفحة $no", M, H - 24f, text(MUTED, 10f, align = Paint.Align.LEFT))
        }

        fun newPage() {
            if (no > 0) { footer(); doc.finishPage(page) }
            no++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, no).create())
            y = M
        }

        fun ensure(h: Float) { if (y + h > H - 60) newPage() }
        fun finish() { footer(); doc.finishPage(page) }
    }

    fun build(ctx: Context, store: String, label: String, r: ReportData, stock: StockValue?, stagnant: List<Item>): File {
        val pg = Pages(store)
        pg.newPage()
        val c = pg.c

        // Header band
        c.drawRect(0f, 0f, W.toFloat(), 120f, fill(BRAND))
        val tile = RectF(W - M - 58, 30f, W - M, 88f)
        c.drawRoundRect(tile, 16f, 16f, fill(0x33FFFFFF))
        snowflake(c, tile.centerX(), tile.centerY(), 20f, 0xFFFFFFFF.toInt())
        c.drawText(store, W - M - 72, 56f, fitted(text(0xFFFFFFFF.toInt(), 24f, true), store, 300f))
        c.drawText("تقرير $label", W - M - 72, 80f, text(0xFFE3F2F7.toInt(), 14f))
        c.drawText("${Dates.fmt(r.from)} → ${Dates.fmt(r.to)}", M, 56f, text(0xFFFFFFFF.toInt(), 12f, true, Paint.Align.LEFT))
        c.drawText("تاريخ الإنشاء ${Dates.fmt(Dates.today())}", M, 78f, text(0xFFE3F2F7.toInt(), 11f, align = Paint.Align.LEFT))
        pg.y = 142f

        // Key numbers
        val s = r.current
        val p = r.previous
        val gap = 10f
        val cw = (W - 2 * M - 3 * gap) / 4f
        val cards = listOf(
            Triple("صافي الربح", Fmt.money(s.netProfit), if (s.netProfit >= 0) GOOD else BAD),
            Triple("المبيعات", Fmt.money(s.salesTotal), INK),
            Triple("تكلفة البضاعة", Fmt.money(s.cogs), INK),
            Triple("المصاريف", Fmt.money(s.expenses), WARN),
        )
        cards.forEachIndexed { i, (label2, value, color) ->
            val right = W - M - i * (cw + gap)
            val rect = RectF(right - cw, pg.y, right, pg.y + 74f)
            c.drawRoundRect(rect, 12f, 12f, fill(CARD))
            c.drawRoundRect(RectF(right - 5f, pg.y + 14f, right, pg.y + 60f), 3f, 3f, fill(color))
            c.drawText(label2, right - 16f, pg.y + 28f, text(MUTED, 11f))
            c.drawText(value, right - 16f, pg.y + 56f, fitted(text(color, 20f, true), value, cw - 30f))
        }
        pg.y += 90f

        // Comparison badge
        val change = when {
            p.netProfit == 0.0 && s.netProfit == 0.0 -> null
            p.netProfit == 0.0 -> "مفيش فترة سابقة للمقارنة" to MUTED
            else -> {
                val pct = (s.netProfit - p.netProfit) / abs(p.netProfit) * 100
                ((if (pct >= 0) "أعلى" else "أقل") + " من الفترة السابقة بـ ${"%.0f".format(abs(pct))}%") to (if (pct >= 0) GOOD else BAD)
            }
        }
        change?.let { (msg, color) ->
            val tp = text(color, 12f, true)
            val w = tp.measureText(msg) + 28f
            val rect = RectF(W - M - w, pg.y, W - M, pg.y + 26f)
            c.drawRoundRect(rect, 13f, 13f, fill((color and 0x00FFFFFF) or 0x22000000))
            c.drawText(msg, rect.right - 14f, pg.y + 18f, tp)
            pg.y += 40f
        }

        // Summary table
        fun heading(title: String) {
            pg.ensure(60f)
            pg.c.drawRoundRect(RectF(W - M - 6, pg.y, W - M, pg.y + 18f), 3f, 3f, fill(BRAND))
            pg.c.drawText(title, W - M - 16, pg.y + 15f, text(INK, 15f, true))
            pg.y += 30f
        }
        heading("ملخص الحساب")
        val colCur = 340f
        val colPrev = 200f
        pg.c.drawRoundRect(RectF(M, pg.y, W - M, pg.y + 28f), 8f, 8f, fill(0xFFE3EEF3.toInt()))
        pg.c.drawText("البند", W - M - 12, pg.y + 19f, text(INK, 12f, true))
        pg.c.drawText("الفترة الحالية", colCur, pg.y + 19f, text(INK, 12f, true))
        pg.c.drawText("الفترة السابقة", colPrev, pg.y + 19f, text(INK, 12f, true))
        pg.y += 28f
        val rows = listOf(
            Triple("عدد الفواتير", "${s.salesCount}", "${p.salesCount}"),
            Triple("المبيعات", Fmt.money(s.salesTotal), Fmt.money(p.salesTotal)),
            Triple("المرتجعات", Fmt.money(s.refunds), Fmt.money(p.refunds)),
            Triple("إجمالي الربح", Fmt.money(s.grossProfit), Fmt.money(p.grossProfit)),
            Triple("هالك وعجز", Fmt.money(s.wasteCost), Fmt.money(p.wasteCost)),
            Triple("المصاريف", Fmt.money(s.expenses), Fmt.money(p.expenses)),
            Triple("صافي الربح", Fmt.money(s.netProfit), Fmt.money(p.netProfit)),
        )
        rows.forEachIndexed { i, (name, cur, prev) ->
            pg.ensure(28f)
            val last = i == rows.lastIndex
            if (i % 2 == 0) pg.c.drawRect(M, pg.y, W - M, pg.y + 26f, fill(ZEBRA))
            pg.c.drawText(name, W - M - 12, pg.y + 18f, text(INK, 12f, last))
            pg.c.drawText(cur, colCur, pg.y + 18f, text(if (last) (if (s.netProfit >= 0) GOOD else BAD) else INK, 12f, last))
            pg.c.drawText(prev, colPrev, pg.y + 18f, text(MUTED, 12f))
            pg.y += 26f
        }
        pg.y += 14f

        fun bars(title: String, items: List<Pair<String, Double>>, fmt: (Double) -> String) {
            heading(title)
            if (items.isEmpty()) {
                pg.c.drawText("لسه مفيش مبيعات في الفترة دي.", W - M - 12, pg.y + 12f, text(MUTED, 12f)); pg.y += 28f; return
            }
            val max = items.maxOf { it.second }.takeIf { it > 0 } ?: 1.0
            val trackL = M + 70f
            val trackR = W - M - 170f
            items.forEach { (name, v) ->
                pg.ensure(28f)
                pg.c.drawText(name, W - M - 12, pg.y + 14f, fitted(text(INK, 12f), name, 150f))
                pg.c.drawRoundRect(RectF(trackL, pg.y + 6f, trackR, pg.y + 14f), 4f, 4f, fill(0xFFE5EDF2.toInt()))
                val w = ((trackR - trackL) * (v / max)).toFloat().coerceAtLeast(6f)
                pg.c.drawRoundRect(RectF(trackR - w, pg.y + 6f, trackR, pg.y + 14f), 4f, 4f, fill(BRAND))
                pg.c.drawText(fmt(v), M, pg.y + 14f, text(INK, 12f, true, Paint.Align.LEFT))
                pg.y += 28f
            }
            pg.y += 10f
        }
        bars("أعلى الأصناف مبيعًا (بالكمية)", r.topSold.map { it.name to it.qty.toDouble() }) { "${it.toInt()}" }
        bars("أعلى الأصناف ربحًا", r.topProfit.map { it.name to it.profit }) { Fmt.money(it) }

        if (stock != null) {
            heading("قيمة المخزون (مخزن + عربية)")
            pg.ensure(70f)
            listOf("بسعر التكلفة" to stock.cost, "بسعر البيع" to stock.sell).forEachIndexed { i, (name, v) ->
                val half = (W - 2 * M - 10f) / 2f
                val right = W - M - i * (half + 10f)
                pg.c.drawRoundRect(RectF(right - half, pg.y, right, pg.y + 56f), 12f, 12f, fill(CARD))
                pg.c.drawText(name, right - 14f, pg.y + 22f, text(MUTED, 11f))
                pg.c.drawText(Fmt.money(v), right - 14f, pg.y + 46f, fitted(text(INK, 20f, true), Fmt.money(v), half - 28f))
            }
            pg.y += 72f
        }

        heading("الأصناف الراكدة (مفيهاش بيع من ٣٠ يوم)")
        if (stagnant.isEmpty()) {
            pg.c.drawText("مفيش أصناف راكدة.", W - M - 12, pg.y + 12f, text(GOOD, 12f, true)); pg.y += 28f
        } else {
            stagnant.take(12).forEach {
                pg.ensure(22f)
                pg.c.drawText("• ${it.name}", W - M - 12, pg.y + 12f, text(INK, 12f)); pg.y += 22f
            }
            if (stagnant.size > 12) { pg.ensure(22f); pg.c.drawText("و ${stagnant.size - 12} أصناف تانية", W - M - 12, pg.y + 12f, text(MUTED, 11f)); pg.y += 22f }
        }
        pg.finish()

        val file = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "report-${Dates.fmt(r.to)}.pdf")
        FileOutputStream(file).use { pg.doc.writeTo(it) }
        pg.doc.close()
        return file
    }

    fun share(ctx: Context, store: String, label: String, r: ReportData, stock: StockValue?, stagnant: List<Item>) {
        Exporter.share(ctx, build(ctx, store, label, r, stock, stagnant), "application/pdf")
    }

    /** Prints a PDF file that already exists (receipts, statements). ctx must be an Activity. */
    fun printFile(ctx: Context, file: File, name: String) {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(name, object : PrintDocumentAdapter() {
            override fun onLayout(old: PrintAttributes?, new: PrintAttributes?, cancel: CancellationSignal?, cb: LayoutResultCallback, extras: Bundle?) {
                if (cancel?.isCanceled == true) { cb.onLayoutCancelled(); return }
                cb.onLayoutFinished(PrintDocumentInfo.Builder(file.name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(), true)
            }

            override fun onWrite(pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cancel: CancellationSignal?, cb: WriteResultCallback) {
                try {
                    FileInputStream(file).use { i -> FileOutputStream(dest.fileDescriptor).use { o -> i.copyTo(o) } }
                    cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) { cb.onWriteFailed(e.message) }
            }
        }, null)
    }

    /** Opens the Android print dialog (any printer, or "Save as PDF"). ctx must be an Activity. */
    fun print(ctx: Context, store: String, label: String, r: ReportData, stock: StockValue?, stagnant: List<Item>) {
        val file = build(ctx, store, label, r, stock, stagnant)
        val name = "تقرير $label - $store"
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(name, object : PrintDocumentAdapter() {
            override fun onLayout(old: PrintAttributes?, new: PrintAttributes?, cancel: CancellationSignal?, cb: LayoutResultCallback, extras: Bundle?) {
                if (cancel?.isCanceled == true) { cb.onLayoutCancelled(); return }
                cb.onLayoutFinished(
                    PrintDocumentInfo.Builder(file.name).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(),
                    true,
                )
            }

            override fun onWrite(pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cancel: CancellationSignal?, cb: WriteResultCallback) {
                try {
                    FileInputStream(file).use { i -> FileOutputStream(dest.fileDescriptor).use { o -> i.copyTo(o) } }
                    cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    cb.onWriteFailed(e.message)
                }
            }
        }, null)
    }
}
