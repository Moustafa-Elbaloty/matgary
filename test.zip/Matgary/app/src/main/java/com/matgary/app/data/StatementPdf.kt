package com.matgary.app.data

import android.content.Context
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.matgary.app.data.db.Customer
import java.io.File
import java.io.FileOutputStream

/** One customer's account statement on A4: balance card and every invoice and payment with the running balance. */
object StatementPdf {
    private const val W = 595
    private const val H = 842
    private const val M = 36f
    private val WHITE = 0xFFFFFFFF.toInt()

    fun build(ctx: Context, store: String, customer: Customer, balance: Double, ledger: List<LedgerEntry>): File {
        val doc = PdfDocument()
        var no = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, no).create())
        var c = page.canvas
        val fill = PdfReport::fill
        val text = PdfReport::text

        fun footer() {
            c.drawRect(M, H - 42f, W - M, H - 41f, fill(0xFFE2EAEF.toInt()))
            c.drawText("$store · تطوير مصطفى البلوطي", W - M, H - 24f, text(PdfReport.MUTED, 10f, false, Paint.Align.RIGHT))
            c.drawText("صفحة $no", M, H - 24f, text(PdfReport.MUTED, 10f, false, Paint.Align.LEFT))
        }

        fun tableHeader(y: Float) {
            c.drawRoundRect(RectF(M, y, W - M, y + 28f), 8f, 8f, fill(0xFFE3EEF3.toInt()))
            val h = text(PdfReport.INK, 12f, true, Paint.Align.RIGHT)
            c.drawText("التاريخ", W - M - 10, y + 19f, h)
            c.drawText("البيان", W - M - 100, y + 19f, h)
            c.drawText("عليه", 215f, y + 19f, h)
            c.drawText("دفعة", 140f, y + 19f, h)
            c.drawText("الرصيد", M + 70f, y + 19f, h)
        }

        // Header
        c.drawRect(0f, 0f, W.toFloat(), 118f, fill(PdfReport.BRAND))
        val tile = RectF(W - M - 58, 30f, W - M, 88f)
        c.drawRoundRect(tile, 16f, 16f, fill(0x33FFFFFF))
        PdfReport.snowflake(c, tile.centerX(), tile.centerY(), 20f, WHITE)
        c.drawText(store, W - M - 72, 56f, PdfReport.fitted(text(WHITE, 24f, true, Paint.Align.RIGHT), store, 300f))
        c.drawText("كشف حساب عميل", W - M - 72, 80f, text(0xFFE3F2F7.toInt(), 14f, false, Paint.Align.RIGHT))
        c.drawText(Dates.fmt(Dates.today()), M, 56f, text(WHITE, 12f, true, Paint.Align.LEFT))

        // Customer + balance
        var y = 140f
        c.drawRoundRect(RectF(M, y, W - M, y + 86f), 14f, 14f, fill(PdfReport.CARD))
        c.drawText(customer.name, W - M - 18, y + 34f, PdfReport.fitted(text(PdfReport.INK, 20f, true, Paint.Align.RIGHT), customer.name, 280f))
        if (customer.phone.isNotBlank()) c.drawText(customer.phone, W - M - 18, y + 58f, text(PdfReport.MUTED, 12f, false, Paint.Align.RIGHT))
        c.drawText("المتبقي عليه", M + 150f, y + 30f, text(PdfReport.MUTED, 11f, false, Paint.Align.RIGHT))
        val bal = if (balance > 0.005) Fmt.money(balance) else "مفيش مديونية"
        c.drawText(bal, M + 150f, y + 62f, PdfReport.fitted(text(if (balance > 0.005) PdfReport.WARN else PdfReport.GOOD, 24f, true, Paint.Align.RIGHT), bal, 150f))
        y += 108f

        tableHeader(y)
        y += 28f
        val rows = ledger.sortedBy { it.time }
        rows.forEachIndexed { i, e ->
            if (y > H - 70f) {
                footer(); doc.finishPage(page); no++
                page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, no).create()); c = page.canvas
                y = M
                tableHeader(y); y += 28f
            }
            if (i % 2 == 0) c.drawRect(M, y, W - M, y + 26f, fill(PdfReport.ZEBRA))
            c.drawText(Dates.fmt(e.day), W - M - 10, y + 18f, text(PdfReport.INK, 11f, false, Paint.Align.RIGHT))
            c.drawText(e.title, W - M - 100, y + 18f, PdfReport.fitted(text(PdfReport.INK, 11f, false, Paint.Align.RIGHT), e.title, 190f))
            if (e.amount > 0) c.drawText(Fmt.money(e.amount), 215f, y + 18f, text(PdfReport.WARN, 11f, true, Paint.Align.RIGHT))
            else c.drawText(Fmt.money(-e.amount), 140f, y + 18f, text(PdfReport.GOOD, 11f, true, Paint.Align.RIGHT))
            c.drawText(Fmt.money(e.balanceAfter), M + 70f, y + 18f, text(PdfReport.INK, 11f, true, Paint.Align.RIGHT))
            y += 26f
        }
        if (rows.isEmpty()) c.drawText("لسه مفيش حركات.", W - M - 10, y + 20f, text(PdfReport.MUTED, 12f, false, Paint.Align.RIGHT))
        footer()
        doc.finishPage(page)

        val file = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "statement-${customer.id}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun share(ctx: Context, store: String, customer: Customer, balance: Double, ledger: List<LedgerEntry>) {
        Exporter.share(ctx, build(ctx, store, customer, balance, ledger), "application/pdf")
    }
}
