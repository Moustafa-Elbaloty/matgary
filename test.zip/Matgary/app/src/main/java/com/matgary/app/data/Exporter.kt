package com.matgary.app.data

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/** Turns a report into a PDF or an Excel-readable CSV file and opens the share sheet. */
object Exporter {
    fun reportLines(store: String, label: String, r: ReportData): List<Pair<String, String>> = buildList {
        val s = r.current
        add("التقرير" to "$store - $label")
        add("الفترة" to "${Dates.fmt(r.from)} إلى ${Dates.fmt(r.to)}")
        add("عدد الفواتير" to "${s.salesCount}")
        add("المبيعات" to Fmt.money(s.salesTotal))
        add("المرتجعات" to Fmt.money(s.refunds))
        add("إجمالي الربح" to Fmt.money(s.grossProfit))
        add("هالك وعجز" to Fmt.money(s.wasteCost))
        add("المصاريف" to Fmt.money(s.expenses))
        add("صافي الربح" to Fmt.money(s.netProfit))
        add("صافي ربح الفترة السابقة" to Fmt.money(r.previous.netProfit))
        add("أعلى الأصناف مبيعًا" to "الكمية")
        r.topSold.forEach { add(it.name to "${it.qty}") }
        add("أعلى الأصناف ربحًا" to "الربح")
        r.topProfit.forEach { add(it.name to Fmt.money(it.profit)) }
    }

    private fun exportFile(ctx: Context, name: String) =
        File(File(ctx.cacheDir, "exports").apply { mkdirs() }, name)

    fun share(ctx: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "مشاركة التقرير"))
    }

    fun shareBytes(ctx: Context, fileName: String, bytes: ByteArray, mime: String = "application/octet-stream") {
        val file = exportFile(ctx, fileName)
        file.writeBytes(bytes)
        share(ctx, file, mime)
    }

    fun shareCsv(ctx: Context, fileName: String, lines: List<Pair<String, String>>) {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val file = exportFile(ctx, fileName)
        // The BOM makes Excel read the Arabic text correctly.
        file.writeText("\uFEFF" + lines.joinToString("\r\n") { "${q(it.first)},${q(it.second)}" }, Charsets.UTF_8)
        share(ctx, file, "text/csv")
    }

    fun sharePdf(ctx: Context, fileName: String, lines: List<Pair<String, String>>) {
        val doc = PdfDocument()
        val text = Paint().apply { isAntiAlias = true; textSize = 14f }
        val bold = Paint(text).apply { typeface = Typeface.DEFAULT_BOLD; textSize = 16f }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo).create())
        var y = 60f
        lines.forEachIndexed { i, (label, value) ->
            if (y > 790f) {
                doc.finishPage(page)
                page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, ++pageNo).create())
                y = 60f
            }
            val paint = if (i == 0) bold else text
            paint.textAlign = Paint.Align.RIGHT
            page.canvas.drawText(label, 555f, y, paint)
            paint.textAlign = Paint.Align.LEFT
            page.canvas.drawText(value, 40f, y, paint)
            y += if (i == 0) 34f else 26f
        }
        doc.finishPage(page)
        val file = exportFile(ctx, fileName)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        share(ctx, file, "application/pdf")
    }
}
