package com.matgary.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.data.Dates
import com.matgary.app.data.Fmt
import com.matgary.app.data.ReportData
import com.matgary.app.data.StockValue
import com.matgary.app.data.db.Item
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme
import kotlin.math.abs

val REPORT_RANGES = listOf("يومي" to 1, "أسبوعي" to 7, "شهري" to 30)

@Composable
private fun Bars(rows: List<Pair<String, Double>>, format: (Double) -> String) {
    val c = AppTheme.colors
    val max = rows.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: 1.0
    rows.forEach { (name, v) ->
        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, color = c.ink, fontSize = 14.sp)
                Text(format(v), color = c.ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(c.glassBorder)) {
                Box(Modifier.fillMaxWidth((v / max).toFloat().coerceIn(0.02f, 1f)).height(10.dp).clip(RoundedCornerShape(5.dp)).background(c.accent))
            }
        }
    }
}

@Composable
fun ReportsScreen(
    rangeIndex: Int, onRange: (Int) -> Unit, report: ReportData?, stock: StockValue?, stagnant: List<Item>,
    onPdf: () -> Unit, onCsv: () -> Unit, onPrint: () -> Unit, onBack: () -> Unit,
) {
    val c = AppTheme.colors
    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            TopBar("التقارير", onBack)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                REPORT_RANGES.forEachIndexed { i, (label, _) ->
                    FilterChip(selected = i == rangeIndex, onClick = { onRange(i) }, label = { Text(label) })
                }
            }
            if (report == null) {
                Text("جاري الحساب...", color = c.muted, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
            } else {
                val cur = report.current
                val prev = report.previous
                val change = when {
                    prev.netProfit == 0.0 && cur.netProfit == 0.0 -> "مفيش حركة في الفترتين"
                    prev.netProfit == 0.0 -> "مفيش فترة سابقة للمقارنة"
                    else -> {
                        val p = (cur.netProfit - prev.netProfit) / abs(prev.netProfit) * 100
                        (if (p >= 0) "أعلى" else "أقل") + " من الفترة اللي فاتت بـ ${"%.0f".format(abs(p))}%"
                    }
                }
                Text("${Dates.fmt(report.from)} → ${Dates.fmt(report.to)}", color = c.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                GlassCard(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("صافي الربح", color = c.muted, fontSize = 13.sp)
                        Text(Fmt.money(cur.netProfit), color = if (cur.netProfit >= 0) c.good else c.danger, fontSize = 32.sp, fontWeight = FontWeight.Black)
                        Text(change, color = c.muted, fontSize = 13.sp)
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("مبيعات ${Fmt.money(cur.salesTotal)}", color = c.ink, fontSize = 13.sp)
                            Text("تكلفة ${Fmt.money(cur.cogs)}", color = c.ink, fontSize = 13.sp)
                            Text("مصاريف ${Fmt.money(cur.expenses)}", color = c.ink, fontSize = 13.sp)
                        }
                        Text("الفترة السابقة: مبيعات ${Fmt.money(prev.salesTotal)} · صافي ${Fmt.money(prev.netProfit)}", color = c.muted, fontSize = 12.sp)
                    }
                }
                Section("أعلى الأصناف مبيعًا") {
                    if (report.topSold.isEmpty()) Text("لسه مفيش مبيعات في الفترة دي.", color = c.muted, fontSize = 13.sp)
                    else Bars(report.topSold.map { it.name to it.qty.toDouble() }) { "${it.toInt()}" }
                }
                Section("أعلى الأصناف ربحًا") {
                    if (report.topProfit.isEmpty()) Text("لسه مفيش مبيعات في الفترة دي.", color = c.muted, fontSize = 13.sp)
                    else Bars(report.topProfit.map { it.name to it.profit }) { Fmt.money(it) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onPdf, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                        Text("تصدير PDF", color = c.accent, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onCsv, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                        Text("تصدير Excel", color = c.accent, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onPrint, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                        Text("طباعة", color = c.accent, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (stock != null) Section("قيمة المخزون (مخزن + عربية)") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("بسعر التكلفة", color = c.muted, fontSize = 12.sp)
                        Text(Fmt.money(stock.cost), color = c.ink, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("بسعر البيع", color = c.muted, fontSize = 12.sp)
                        Text(Fmt.money(stock.sell), color = c.ink, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
            Section("الأصناف الراكدة (مفيهاش بيع بقالها ٣٠ يوم)") {
                if (stagnant.isEmpty()) Text("مفيش أصناف راكدة.", color = c.good, fontSize = 13.sp)
                stagnant.forEach { Text("• ${it.name}", color = c.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            }
            Box(Modifier.padding(bottom = 24.dp))
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    val c = AppTheme.colors
    Text(title, color = c.ink, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
    GlassCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { content() } }
}
