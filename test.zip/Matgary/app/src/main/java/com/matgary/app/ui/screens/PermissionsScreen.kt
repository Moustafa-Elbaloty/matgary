package com.matgary.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.matgary.app.ui.components.AppLogo
import com.matgary.app.ui.components.GlassCard
import com.matgary.app.ui.components.ScreenBackground
import com.matgary.app.ui.theme.AppTheme

data class PermState(val notif: Boolean, val camera: Boolean, val overlay: Boolean, val battery: Boolean) {
    val all get() = notif && camera && overlay && battery
}

/** Shown once on the first run (and again from Settings): asks for what the app needs, one card per permission. */
@Composable
fun PermissionsScreen(
    state: PermState,
    onNotif: () -> Unit, onCamera: () -> Unit, onOverlay: () -> Unit, onBattery: () -> Unit,
    onAll: () -> Unit, onAppSettings: () -> Unit, onDone: () -> Unit,
) {
    val c = AppTheme.colors

    @Composable
    fun Card(title: String, desc: String, granted: Boolean, onAllow: () -> Unit) {
        GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, color = c.ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(desc, color = c.muted, fontSize = 12.sp)
                }
                if (granted) Text("✓ مفعّل", color = c.good, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                else Button(
                    onClick = onAllow, shape = RoundedCornerShape(20.dp), modifier = Modifier.height(40.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent),
                ) { Text("السماح", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }

    ScreenBackground {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            AppLogo(72.dp)
            Spacer(Modifier.height(12.dp))
            Text("جهّز التطبيق", color = c.ink, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("كل الأذونات دي اختيارية، وتقدر تغيّرها بعدين من الإعدادات.", color = c.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 16.dp))
            Card("الإشعارات", "تنبيهات الأصناف الناقصة وقرب الصلاحية والعملاء المتأخرين.", state.notif, onNotif)
            Card("الكاميرا", "لمسح باركود الأصناف في البيع والمخزن.", state.camera, onCamera)
            Card("الظهور فوق التطبيقات", "عشان التنبيه ينزل بشكل الجزيرة فوق أي شاشة. هتتفتحلك صفحة الإعدادات، فعّل \"متجري\".", state.overlay, onOverlay)
            Card("الشغل في الخلفية", "عشان التنبيهات توصل في وقتها حتى لو التطبيق مقفول.", state.battery, onBattery)
            Spacer(Modifier.height(8.dp))
            PrimaryButton("السماح بكل الأذونات", enabled = !state.all, onClick = onAll)
            OutlinedButton(onClick = onDone, modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Text(if (state.all) "متابعة" else "تخطّي ومتابعة", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            TextButton(onClick = onAppSettings) { Text("لو مفيش نافذة بتظهر: افتح إعدادات التطبيق", color = c.muted, fontSize = 12.sp) }
        }
    }
}
