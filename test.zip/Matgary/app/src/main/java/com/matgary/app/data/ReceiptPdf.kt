package com.matgary.app.data

import android.content.Context
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.matgary.app.data.db.Sale
import com.matgary.app.data.db.SaleLine
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A compact receipt (about 80 mm wide) in the same look as the report. Share it on WhatsApp or print it. */
object ReceiptPdf {
    private const val W = 300
    private val WHITE = 0xFFFFFFFF.toInt()

    fun payLabel(p: String) = when (p) { "CASH" -> "كاش"; "WALLET" -> "محفظة"; else -> "أجل" }

    fun build(ctx: Context, store: String, sale: Sale, lines: List<SaleLine>, customer: String?): File {
        val rowH = 24f
        val h = (150f + lines.size * rowH + 210f).toInt()
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(W, h, 1).create())
        val c = page.canvas
        val fill = PdfReport::fill
        val text = PdfReport::text

        c.drawRect(0f, 0f, W.toFloat(), 84f, fill(PdfReport.BRAND))
        PdfReport.snowflake(c, W - 36f, 42f, 16f, WHITE)
        c.drawText(store, W - 62f, 38f, PdfReport.fitted(text(WHITE, 18f, true, Paint.Align.RIGHT), store, 190f))
        c.drawText("إيصال بيع", W - 62f, 60f, text(0xFFE3F2F7.toInt(), 12f, false, Paint.Align.RIGHT))
        c.drawText("#${sale.id}", 20f, 38f, text(WHITE, 15f, true, Paint.Align.LEFT))

        var y = 108f
        val dt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(sale.time))
        val info = buildList {
            add("التاريخ: $dt")
            if (!customer.isNullOrBlank()) add("العميل: $customer")
            add("الدفع: ${payLabel(sale.payment)}")
        }
        info.forEach { c.drawText(it, W - 20f, y, text(PdfReport.MUTED, 11f, false, Paint.Align.RIGHT)); y += 18f }
        y += 4f

        c.drawRoundRect(RectF(14f, y, W - 14f, y + 24f), 8f, 8f, fill(0xFFE3EEF3.toInt()))
        c.drawText("الصنف", W - 20f, y + 16f, text(PdfReport.INK, 11f, true, Paint.Align.RIGHT))
        c.drawText("الكمية × السعر", 172f, y + 16f, text(PdfReport.INK, 11f, true, Paint.Align.RIGHT))
        c.drawText("الإجمالي", 20f, y + 16f, text(PdfReport.INK, 11f, true, Paint.Align.LEFT))
        y += 24f
        lines.forEachIndexed { i, l ->
            if (i % 2 == 0) c.drawRect(14f, y, W - 14f, y + rowH, fill(PdfReport.ZEBRA))
            c.drawText(l.name, W - 20f, y + 16f, PdfReport.fitted(text(PdfReport.INK, 12f, false, Paint.Align.RIGHT), l.name, 115f))
            c.drawText("${l.qty} × ${Fmt.money(l.unitPrice)}", 172f, y + 16f, text(PdfReport.MUTED, 11f, false, Paint.Align.RIGHT))
            c.drawText(Fmt.money(l.qty * l.unitPrice), 20f, y + 16f, text(PdfReport.INK, 12f, true, Paint.Align.LEFT))
            y += rowH
        }
        y += 10f

        fun row(label: String, value: String, color: Int = PdfReport.INK) {
            c.drawText(label, W - 20f, y, text(PdfReport.MUTED, 12f, false, Paint.Align.RIGHT))
            c.drawText(value, 20f, y, text(color, 12f, true, Paint.Align.LEFT))
            y += 20f
        }
        val gross = lines.sumOf { it.qty * it.unitPrice }
        row("المجموع", Fmt.money(gross))
        if (sale.discount > 0) row("الخصم", "- ${Fmt.money(sale.discount)}", PdfReport.WARN)
        y += 4f
        c.drawRoundRect(RectF(14f, y - 14f, W - 14f, y + 30f), 12f, 12f, fill(PdfReport.CARD))
        c.drawText("الإجمالي", W - 24f, y + 14f, text(PdfReport.INK, 15f, true, Paint.Align.RIGHT))
        c.drawText(Fmt.money(sale.total), 24f, y + 15f, PdfReport.fitted(text(PdfReport.BRAND, 20f, true, Paint.Align.LEFT), Fmt.money(sale.total), 120f))
        y += 52f
        if (sale.payment == "CREDIT") {
            row("المدفوع", Fmt.money(sale.paid))
            row("المتبقي على العميل", Fmt.money(sale.total - sale.paid), PdfReport.WARN)
        }
        y += 12f
        c.drawText("شكرًا لتعاملكم معانا", W / 2f, y, text(PdfReport.BRAND, 13f, true, Paint.Align.CENTER))
        c.drawText("$store · متجري", W / 2f, y + 16f, text(PdfReport.MUTED, 9f, false, Paint.Align.CENTER))
        doc.finishPage(page)

        val file = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, "receipt-${sale.id}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
