Matgary (متجري) - Step 2: protection

How the protection works
- Activation codes are signed with the owner's private key (ECDSA P-256). The app only holds the PUBLIC key.
- The private key is created inside the Android Keystore of the OWNER's phone and cannot be exported.
- A code is bound to one phone (device code) and can have an expiry date.
- The license is stored encrypted (AES-GCM, key in Keystore). Moving the phone clock back is detected.

One-time owner setup
1. Run the app. On the activation screen, tap the logo 7 times -> create the owner account -> copy the public key.
2. Paste it into data/TrustedKey.kt (PUBLIC_KEY_B64) and rebuild. Install over the old app. DO NOT uninstall it from your phone.
3. Tap the logo 7 times -> log in -> enter the customer's device code -> choose a duration -> send the code.
4. Release builds: use Build > Generate Signed Bundle/APK (R8 obfuscation is already on).

Step 3: encrypted items and inventory. Step 4: truck loading. Step 5: sales from the truck, returns, waste. Step 6: debts (balance per customer, partial payments, overdue tags, WhatsApp reminder, call). Step 7: expenses, day closing, truck count. Step 8: real home screen, settings, reports with comparison and export. Step 9: PIN and fingerprint lock, password-encrypted backup and restore. Step 10: barcode scanning, island alerts, launcher icon. Update: system back button goes one screen back, clearer back button, activation can be switched off for testing (data/Config.kt REQUIRE_ACTIVATION), phone-wide Dynamic Island style alerts (overlay + notifications, WorkManager every 6 hours).

Cloud builds: see RELEASE.txt and the repository workflow. Every build is published as a GitHub release with a direct matgary.apk link.
builds a debug APK in the cloud (Actions tab > latest run > matgary-debug-apk). Download it on the phone and install it.
Each cloud build is signed with a different debug key, so uninstall the old one before installing a new one (this deletes its data).
Step 11: cancel invoice (goods return to the truck) with audit log, invoices list, receipt PDF (share/print) after each sale, customer statement PDF.
